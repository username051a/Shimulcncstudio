"""Download the free AI model (Depth Anything V2 Small, ONNX, Apache-2.0) into ./models.

The build scripts run this so the installer ships with the model and works offline from the first start.
Use --required to make a failed download stop the build.
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from shimul_cnc.ai.model_manager import MODEL_FILENAME, download_model  # noqa: E402


def main() -> int:
    target = ROOT / "models" / MODEL_FILENAME
    if target.exists() and target.stat().st_size > 90_000_000:
        print(f"Model already present: {target}")
        return 0
    last = [-1]

    def progress(frac, msg):
        pct = int(frac * 100)
        if pct != last[0] and pct % 10 == 0:
            last[0] = pct
            print(f"  {pct:3d}%  {msg}", flush=True)

    try:
        path = download_model(progress, dest_dir=target.parent)
        print(f"Downloaded: {path} ({path.stat().st_size / 1e6:.1f} MB)")
        return 0
    except Exception as e:                          # noqa: BLE001
        print(f"WARNING: could not download the AI model: {e}")
        print("The program still works; it offers to download the model at the first start.")
        return 1 if "--required" in sys.argv else 0


if __name__ == "__main__":
    raise SystemExit(main())
