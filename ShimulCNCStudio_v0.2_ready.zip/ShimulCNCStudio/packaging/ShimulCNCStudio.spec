# -*- mode: python ; coding: utf-8 -*-
# Build:  pyinstaller packaging/ShimulCNCStudio.spec --noconfirm --clean
import os

from PyInstaller.utils.hooks import collect_all, collect_submodules

ROOT = os.path.abspath(os.path.join(SPECPATH, ".."))

datas = [(os.path.join(ROOT, "assets"), "assets")]
models_dir = os.path.join(ROOT, "models")
if os.path.isdir(models_dir) and any(f.endswith(".onnx") for f in os.listdir(models_dir)):
    datas.append((models_dir, "models"))            # AI model travels inside the installer

ort_datas, ort_binaries, ort_hidden = collect_all("onnxruntime")      # includes DirectML.dll on Windows
hidden = (ort_hidden + collect_submodules("OpenGL.platform") + collect_submodules("OpenGL.arrays")
          + ["OpenGL.GL", "OpenGL.GL.shaders"])

excludes = ["tkinter", "matplotlib", "scipy", "pytest", "trimesh", "onnx", "IPython", "notebook",
            "PySide6.QtWebEngineCore", "PySide6.QtWebEngineWidgets", "PySide6.QtQml", "PySide6.QtQuick",
            "PySide6.QtNetwork", "PySide6.QtSql", "PySide6.QtMultimedia", "PySide6.Qt3DCore"]

a = Analysis(
    [os.path.join(ROOT, "run.py")],
    pathex=[ROOT],
    binaries=ort_binaries,
    datas=datas + ort_datas,
    hiddenimports=hidden,
    excludes=excludes,
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, [],
    exclude_binaries=True,
    name="ShimulCNCStudio",
    console=False,
    icon=os.path.join(ROOT, "assets", "icon.ico"),
    upx=False,
)
coll = COLLECT(exe, a.binaries, a.datas, upx=False, name="ShimulCNCStudio")
