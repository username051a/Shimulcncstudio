; Inno Setup script. Build:  ISCC.exe /DMyAppVersion=0.2.0 packaging\installer.iss
#ifndef MyAppVersion
  #define MyAppVersion "0.2.0"
#endif
#define MyAppName "Shimul CNC Studio"
#define MyAppExe "ShimulCNCStudio.exe"

[Setup]
AppId={{B7F6C5C2-5C1B-4E0B-9E52-3B6D8D2B7A11}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher=Shimul
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
OutputDir=..\dist
OutputBaseFilename=ShimulCNCStudio_Setup_{#MyAppVersion}
SetupIconFile=..\assets\icon.ico
UninstallDisplayIcon={app}\{#MyAppExe}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequiredOverridesAllowed=dialog

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Shortcuts:"

[Files]
Source: "..\dist\ShimulCNCStudio\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExe}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExe}"; Description: "Start {#MyAppName}"; Flags: nowait postinstall skipifsilent
