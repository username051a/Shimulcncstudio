"""Small, dependency-free hardware description for the status bar."""
from __future__ import annotations

import ctypes
import subprocess
import sys


def ram_gb() -> float:
    try:
        if sys.platform == "win32":
            class MEMSTATUS(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("sullAvailExtendedVirtual", ctypes.c_ulonglong)]
            st = MEMSTATUS()
            st.dwLength = ctypes.sizeof(MEMSTATUS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(st))
            return st.ullTotalPhys / 1024 ** 3
        with open("/proc/meminfo") as f:
            return int(f.readline().split()[1]) / 1024 ** 2
    except Exception:
        return 0.0


def _run(cmd: list) -> str:
    flags = 0x08000000 if sys.platform == "win32" else 0      # CREATE_NO_WINDOW
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=5, creationflags=flags)
        return out.stdout.strip() if out.returncode == 0 else ""
    except Exception:
        return ""


def gpu_name() -> str:
    line = _run(["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader"])
    if line:
        name, _, mem = line.splitlines()[0].partition(",")
        return f"{name.strip()} ({mem.strip()})" if mem else name.strip()
    if sys.platform == "win32":
        names = _run(["powershell", "-NoProfile", "-Command",
                      "(Get-CimInstance Win32_VideoController).Name -join '; '"])
        if names:
            return names
    return "GPU not detected"


def describe() -> str:
    ram = ram_gb()
    return f"{gpu_name()}  |  {ram:.0f} GB RAM" if ram else gpu_name()
