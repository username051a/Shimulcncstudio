"""Command line interface:  python -m shimul_cnc input.png output.stl [options]"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import APP_NAME, __version__
from .core import ProcessingMode, ReliefParams, generate_relief, save_png, write_binary_stl
from .core.preview import hillshade


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="shimul_cnc", description=f"{APP_NAME} {__version__} - image to relief STL")
    ap.add_argument("input", help="input image (png/jpg/bmp/tif, 8 or 16 bit)")
    ap.add_argument("output", help="output .stl file")
    ap.add_argument("--width", type=float, default=100.0, help="X size in mm (default 100)")
    ap.add_argument("--relief", type=float, default=3.0, help="relief height in mm (default 3)")
    ap.add_argument("--base", type=float, default=3.0, help="base thickness in mm (default 3)")
    ap.add_argument("--lift", type=float, default=0.1, help="floor lift in mm (default 0.1)")
    ap.add_argument("--level", type=int, default=1, choices=[1, 2, 3, 4, 5], help="mesh detail level (1 = finest)")
    ap.add_argument("--mode", choices=[m.value for m in ProcessingMode], default=ProcessingMode.HIGH_PASS.value)
    ap.add_argument("--negative", action="store_true", help="negative / intaglio")
    ap.add_argument("--invert", action="store_true", help="invert depth (dark = high)")
    ap.add_argument("--no-mask", action="store_true", help="do not remove the background")
    ap.add_argument("--detail-only", action="store_true")
    ap.add_argument("--radius", type=float, default=6.0, help="high-pass radius")
    ap.add_argument("--strength", type=float, default=0.2, help="detail strength")
    ap.add_argument("--smooth", type=float, default=0.0, help="base smooth")
    ap.add_argument("--groove", type=float, default=0.0, help="groove deepen")
    ap.add_argument("--black", type=int, default=0)
    ap.add_argument("--gamma", type=float, default=1.0)
    ap.add_argument("--white", type=int, default=255)
    ap.add_argument("--save-depth", metavar="PNG", help="also save the final depth map")
    ap.add_argument("--save-preview", metavar="PNG", help="also save a shaded preview")
    return ap


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    try:
        params = ReliefParams(
            width_mm=args.width, relief_height_mm=args.relief, base_mm=args.base,
            floor_lift_mm=args.lift, mesh_level=args.level, mode=ProcessingMode(args.mode),
            negative=args.negative, invert_depth=args.invert, use_mask=not args.no_mask,
            detail_only=args.detail_only, highpass_radius=args.radius, detail_strength=args.strength,
            base_smooth=args.smooth, groove_deepen=args.groove,
            black_point=args.black, gamma=args.gamma, white_point=args.white,
        ).validate()

        def progress(frac: float, msg: str) -> None:
            print(f"\r[{frac * 100:5.1f}%] {msg:<32}", end="", flush=True)

        result = generate_relief(args.input, params, progress=progress)
        write_binary_stl(args.output, result.mesh, progress=progress)
        print()
    except (ValueError, OSError) as e:
        print(f"\nError: {e}", file=sys.stderr)
        return 1

    s = result.stats
    print(f"Grid {s.grid[0]} x {s.grid[1]} | vertices {s.vertices:,} | faces {s.faces:,} | "
          f"STL {s.stl_bytes / 1e6:.1f} MB | size {s.size_mm[0]:.1f} x {s.size_mm[1]:.1f} x {s.size_mm[2]:.2f} mm")
    for note in result.notes:
        print("Note:", note)
    if args.save_depth:
        save_png(args.save_depth, result.depth)
    if args.save_preview:
        nx, ny = s.grid
        save_png(args.save_preview,
                 hillshade(result.z_mm, s.size_mm[0] / (nx - 1), s.size_mm[1] / (ny - 1), z_exaggeration=3.0))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
