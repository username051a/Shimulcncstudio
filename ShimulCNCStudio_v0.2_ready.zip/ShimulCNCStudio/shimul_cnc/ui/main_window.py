"""Main window: sidebar workflow, top bar, status bar, menus, drag and drop."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QSettings, QSize, Qt, QUrl
from PySide6.QtGui import QAction, QDesktopServices, QKeySequence
from PySide6.QtWidgets import (QButtonGroup, QFileDialog, QFrame, QHBoxLayout, QLabel, QMainWindow, QMessageBox,
                               QProgressBar, QStackedWidget, QToolButton, QVBoxLayout, QWidget)

from .. import APP_NAME, __version__
from ..ai import user_models_dir
from ..licensing import check_license
from . import theme
from .icons import nav_icon
from .pages import CropPage, DesignPage, MeshPage
from .state import AppState
from .widgets import button

IMAGE_EXT = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"}
IMAGE_FILTER = "Images (*.png *.jpg *.jpeg *.bmp *.tif *.tiff *.webp);;All files (*)"


class MainWindow(QMainWindow):
    def __init__(self, state: AppState, force_software: bool = False):
        super().__init__()
        self.state = state
        self.settings = QSettings("ShimulCNC", "Studio")
        self._asked_model = False
        self.setWindowTitle(APP_NAME)
        self.setAcceptDrops(True)
        self.resize(1400, 860)
        self.setMinimumSize(1240, 700)

        central = QWidget()
        central.setObjectName("root")
        outer = QHBoxLayout(central)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        self.setCentralWidget(central)

        # ---- sidebar
        side = QFrame()
        side.setObjectName("sidebar")
        side.setFixedWidth(86)
        sl = QVBoxLayout(side)
        sl.setContentsMargins(0, 12, 0, 12)
        sl.setSpacing(2)
        self.nav = QButtonGroup(self)
        self.nav.setExclusive(True)
        for i, (text, kind) in enumerate((("Design", "design"), ("Crop", "crop"), ("Mesh", "mesh"))):
            b = QToolButton()
            b.setObjectName("sideBtn")
            b.setText(text)
            b.setIcon(nav_icon(kind))
            b.setIconSize(QSize(26, 26))
            b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
            b.setCheckable(True)
            b.setCursor(Qt.PointingHandCursor)
            b.setFixedHeight(74)
            b.setSizePolicy(b.sizePolicy().horizontalPolicy(), b.sizePolicy().verticalPolicy())
            b.setMinimumWidth(86)
            self.nav.addButton(b, i)
            sl.addWidget(b)
        sl.addStretch(1)
        outer.addWidget(side)

        # ---- right side: top bar + pages
        col = QVBoxLayout()
        col.setSpacing(0)
        outer.addLayout(col, 1)

        top = QFrame()
        top.setObjectName("topbar")
        tl = QHBoxLayout(top)
        tl.setContentsMargins(16, 8, 16, 8)
        tl.setSpacing(10)
        brand = QLabel(APP_NAME)
        brand.setObjectName("brand")
        tl.addWidget(brand)
        tl.addSpacing(14)
        self.btn_open = button("Open image…", primary=True)
        self.btn_open.clicked.connect(self.open_image)
        tl.addWidget(self.btn_open)
        tl.addStretch(1)
        self.btn_export_top = button("Export STL", primary=True, tip="Ctrl+E")
        self.btn_export_top.clicked.connect(self.export_stl)
        tl.addWidget(self.btn_export_top)
        lic = check_license()
        badge = QLabel(lic.edition)
        badge.setObjectName("badge")
        tl.addWidget(badge)
        col.addWidget(top)

        self.stack = QStackedWidget()
        self.design = DesignPage(state)
        self.crop = CropPage(state)
        self.mesh = MeshPage(state, force_software)
        for pg in (self.design, self.crop, self.mesh):
            self.stack.addWidget(pg)
        col.addWidget(self.stack, 1)

        self.nav.idClicked.connect(self.stack.setCurrentIndex)
        self.nav.button(2).setChecked(True)
        self.stack.setCurrentIndex(2)
        self.design.gotoMesh.connect(lambda: self.show_page(2))
        self.design.openRequested.connect(self.open_image)
        self.mesh.gotoCrop.connect(lambda: self.show_page(1))
        self.mesh.exportRequested.connect(self.export_stl)

        self._build_menu()
        self._build_status()
        self._wire_state()
        self._restore()
        state.detect_hardware()

    # ----------------------------------------------------------------- menus
    def _build_menu(self) -> None:
        mb = self.menuBar()
        f = mb.addMenu("&File")
        for text, key, fn in (("Open image…", QKeySequence.Open, self.open_image),
                              ("Export STL…", QKeySequence("Ctrl+E"), self.export_stl),
                              (None, None, None),
                              ("Save settings as preset…", None, self.save_preset),
                              ("Load preset…", None, self.load_preset),
                              (None, None, None),
                              ("Quit", QKeySequence.Quit, self.close)):
            if text is None:
                f.addSeparator()
                continue
            a = QAction(text, self)
            if key:
                a.setShortcut(key)
            a.triggered.connect(lambda _=False, fn=fn: fn())
            f.addAction(a)
        h = mb.addMenu("&Help")
        a = QAction("Open AI models folder", self)
        a.triggered.connect(lambda: self._open_folder(user_models_dir()))
        h.addAction(a)
        a = QAction("About", self)
        a.triggered.connect(self.about)
        h.addAction(a)

    def _build_status(self) -> None:
        sb = self.statusBar()
        sb.setSizeGripEnabled(False)
        self.dot = QLabel("●")
        self.status_text = QLabel("Ready")
        self.progress = QProgressBar()
        self.progress.setFixedWidth(200)
        self.progress.setRange(0, 100)
        self.progress.hide()
        self.hw = QLabel("")
        self.elapsed = QLabel("")
        sb.addWidget(self.dot)
        sb.addWidget(self.status_text)
        sb.addWidget(self.progress)
        sb.addPermanentWidget(self.hw)
        sb.addPermanentWidget(self.elapsed)
        self._set_dot("ready")

    def _set_dot(self, kind: str) -> None:
        col = {"ready": theme.OK, "busy": theme.ACCENT, "error": theme.DANGER}[kind]
        self.dot.setStyleSheet(f"color: {col}; background: transparent;")

    def _wire_state(self) -> None:
        s = self.state
        s.statusChanged.connect(self._on_status)
        s.progressChanged.connect(self._on_progress)
        s.errorRaised.connect(lambda t, m: QMessageBox.warning(self, t, m))
        s.infoRaised.connect(lambda t, m: QMessageBox.information(self, t, m))
        s.exported.connect(self._on_exported)
        s.sysinfoReady.connect(lambda t: self.hw.setText(f"System: {t}   "))
        s.resultChanged.connect(lambda: self.elapsed.setText(f"Last build {s.elapsed:.2f} s"))

    def _on_status(self, kind: str, text: str) -> None:
        self._set_dot(kind)
        self.status_text.setText(text if kind != "ready" else "Ready")
        self.mesh.vp.set_busy(text if kind == "busy" else "")

    def _on_progress(self, frac: float, msg: str) -> None:
        if frac < 0:
            self.progress.hide()
            return
        self.progress.show()
        self.progress.setValue(int(frac * 100))
        if msg:
            self.status_text.setText(msg)

    # ----------------------------------------------------------------- actions
    def show_page(self, i: int) -> None:
        self.nav.button(i).setChecked(True)
        self.stack.setCurrentIndex(i)

    def _last_dir(self) -> str:
        return self.settings.value("lastDir", str(Path.home()))

    def open_image(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Open image", self._last_dir(), IMAGE_FILTER)
        if path:
            self.load_path(path)

    def load_path(self, path: str) -> None:
        try:
            self.state.open_image(path)
        except Exception as e:
            QMessageBox.warning(self, "Cannot open image", f"{path}\n\n{e}")
            return
        self.settings.setValue("lastDir", str(Path(path).parent))
        self.show_page(2)
        if self.state.model_path is None and not self._asked_model:
            self._asked_model = True
            self.design.ask_download()

    def export_stl(self) -> None:
        if self.state.final is None:
            QMessageBox.information(self, "Export STL", "Open an image first.")
            return
        stem = self.state.source_path.stem if self.state.source_path else "relief"
        start = str(Path(self._last_dir()) / f"{stem}.stl")
        path, _ = QFileDialog.getSaveFileName(self, "Export STL", start, "STL file (*.stl)")
        if path:
            self.state.export_stl(path if path.lower().endswith(".stl") else path + ".stl")

    def _on_exported(self, path: str, size: int) -> None:
        self.settings.setValue("lastDir", str(Path(path).parent))
        box = QMessageBox(self)
        box.setWindowTitle("Export finished")
        box.setText(f"Saved {size / 1e6:.1f} MB:\n{path}")
        box.addButton("Open folder", QMessageBox.ActionRole)
        box.addButton(QMessageBox.Ok)
        box.exec()
        clicked = box.clickedButton()
        if clicked is not None and clicked.text() == "Open folder":
            self._open_folder(Path(path).parent)

    def save_preset(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Save preset", self._last_dir(), "Preset (*.json)")
        if path:
            self.state.save_preset(path if path.endswith(".json") else path + ".json")

    def load_preset(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Load preset", self._last_dir(), "Preset (*.json)")
        if path:
            try:
                self.state.load_preset(path)
            except Exception as e:
                QMessageBox.warning(self, "Cannot load preset", str(e))

    def _open_folder(self, folder: Path) -> None:
        folder.mkdir(parents=True, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder)))

    def about(self) -> None:
        QMessageBox.about(
            self, f"About {APP_NAME}",
            f"<b>{APP_NAME}</b> {__version__}<br>Turns an image into a depth map and a 2.5D relief STL for CNC.<br><br>"
            "AI depth: Depth Anything V2 Small (Apache-2.0), running locally with ONNX Runtime. "
            "Nothing is uploaded; no paid service is used.")

    # ------------------------------------------------------- drag and drop
    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls() and any(Path(u.toLocalFile()).suffix.lower() in IMAGE_EXT for u in e.mimeData().urls()):
            e.acceptProposedAction()

    def dropEvent(self, e):
        for u in e.mimeData().urls():
            if Path(u.toLocalFile()).suffix.lower() in IMAGE_EXT:
                self.load_path(u.toLocalFile())
                break

    # ----------------------------------------------------------- persistence
    def _restore(self) -> None:
        g = self.settings.value("geometry")
        if g:
            self.restoreGeometry(g)
        import json
        from ..core import ReliefParams
        raw = self.settings.value("params")
        if raw:
            try:
                self.state.params = ReliefParams.from_dict(json.loads(raw))
                self.mesh.sync_from_params()
            except Exception:
                pass

    def closeEvent(self, e):
        import json
        self.settings.setValue("geometry", self.saveGeometry())
        self.settings.setValue("params", json.dumps(self.state.params.to_dict()))
        self.state.shutdown()
        super().closeEvent(e)
