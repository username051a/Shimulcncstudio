"""The three workflow pages: Design, Crop and Mesh."""
from __future__ import annotations

from typing import Dict, Optional

import numpy as np
from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QButtonGroup, QCheckBox, QComboBox, QFrame, QGridLayout, QHBoxLayout, QLabel,
                               QMessageBox, QRadioButton, QScrollArea, QSpinBox, QVBoxLayout, QWidget)

from ..core import MESH_LEVELS, ProcessingMode, ReliefParams, estimate_mesh_stats
from .crop_view import CropWidget
from .state import PREVIEW_MIN_LEVEL, AppState
from .viewport import GLViewport
from .widgets import ImageThumb, ParamSlider, Section, SpinRow, button, to_u8

DEFAULTS = ReliefParams()


def _label(text: str, name: str = "", wrap: bool = False) -> QLabel:
    lb = QLabel(text)
    if name:
        lb.setObjectName(name)
    lb.setWordWrap(wrap)
    return lb


def _scroll(inner: QWidget, width: int) -> QScrollArea:
    sa = QScrollArea()
    sa.setWidgetResizable(True)
    sa.setFixedWidth(width)
    sa.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
    sa.setWidget(inner)
    return sa


# ============================================================================ Design
class DesignPage(QWidget):
    gotoMesh = Signal()
    openRequested = Signal()

    def __init__(self, state: AppState):
        super().__init__()
        self.state = state
        root = QHBoxLayout(self)
        root.setContentsMargins(14, 14, 14, 14)
        root.setSpacing(14)

        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 4, 0)
        lv.setSpacing(12)

        s1 = Section("Image")
        self.btn_open = button("Open image…", primary=True)
        self.btn_open.clicked.connect(self.openRequested)
        self.lbl_file = _label("No image yet. Open a photo, drawing or a grayscale depth map.", "hint", True)
        s1.add(self.btn_open)
        s1.add(self.lbl_file)
        lv.addWidget(s1)

        s2 = Section("Depth source")
        self.rb_ai = QRadioButton("AI depth (recommended for photos)")
        self.rb_gray = QRadioButton("Grayscale (brightness = height)")
        s2.add(self.rb_ai)
        s2.add(_label("Depth Anything V2 Small. Free, runs offline on your PC.", "hint", True))
        s2.add(self.rb_gray)
        s2.add(_label("Use this when the image already is a depth map: white is high, black is low.", "hint", True))
        self.lbl_ai = _label("", "hint", True)
        s2.add(self.lbl_ai)
        row = QHBoxLayout()
        self.btn_download = button("Download model (99 MB)")
        self.btn_import = button("Import model file…")
        row.addWidget(self.btn_download)
        row.addWidget(self.btn_import)
        s2.add_layout(row)
        self.btn_rerun = button("Run AI depth again")
        s2.add(self.btn_rerun)
        lv.addWidget(s2)

        self.btn_next = button("Continue to 3D mesh", primary=True)
        self.btn_next.clicked.connect(self.gotoMesh)
        lv.addWidget(self.btn_next)
        lv.addStretch(1)

        root.addWidget(_scroll(left, 360))

        right = QHBoxLayout()
        right.setSpacing(14)
        self.thumb_in = ImageThumb("Your image appears here", 300)
        self.thumb_depth = ImageThumb("The depth map appears here", 300)
        self.title_depth = _label("Depth map", "sectionTitle")
        for title, thumb in ((_label("Original", "sectionTitle"), self.thumb_in), (self.title_depth, self.thumb_depth)):
            box = QFrame()
            box.setObjectName("panel")
            bl = QVBoxLayout(box)
            bl.setContentsMargins(12, 10, 12, 12)
            bl.addWidget(title)
            bl.addWidget(thumb, 1)
            right.addWidget(box, 1)
        root.addLayout(right, 1)

        self.rb_ai.toggled.connect(lambda on: on and state.set_depth_mode("ai"))
        self.rb_gray.toggled.connect(lambda on: on and state.set_depth_mode("gray"))
        self.btn_download.clicked.connect(state.download_model)
        self.btn_rerun.clicked.connect(state.run_ai_depth)
        self.btn_import.clicked.connect(self._import)
        state.imageChanged.connect(self._refresh_image)
        state.depthChanged.connect(self._refresh_depth)
        state.aiChanged.connect(self._refresh_ai)
        state.modelNeeded.connect(self.ask_download)
        self._refresh_ai()

    def _import(self) -> None:
        from PySide6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getOpenFileName(self, "Import depth model", "", "ONNX model (*.onnx)")
        if path:
            self.state.import_model_file(path)

    def ask_download(self) -> None:
        r = QMessageBox.question(
            self, "AI model needed",
            "AI depth needs a free model file (about 99 MB, Apache-2.0 licence).\n"
            "It is downloaded once and then works offline.\n\nDownload it now?")
        if r == QMessageBox.Yes:
            self.state.download_model()

    def _refresh_image(self) -> None:
        s = self.state
        if s.final is None:
            return
        self.thumb_in.set_array(to_u8(s.final.rgb))
        self.thumb_depth.set_array(None)
        name = s.source_path.name if s.source_path else "image"
        self.lbl_file.setText(f"{name}\n{s.final.width} × {s.final.height} px")

    def _refresh_depth(self) -> None:
        s = self.state
        if s.analysis is None:
            return
        self.thumb_depth.set_array(to_u8(s.analysis.depth))
        self.title_depth.setText("Depth map (AI)" if s.depth_mode == "ai" else "Depth map (grayscale)")

    def _refresh_ai(self) -> None:
        s = self.state
        has = s.model_path is not None
        for rb, on in ((self.rb_ai, s.depth_mode == "ai"), (self.rb_gray, s.depth_mode == "gray")):
            rb.blockSignals(True)
            rb.setChecked(on)
            rb.blockSignals(False)
        self.btn_download.setVisible(not has)
        self.btn_import.setVisible(not has)
        self.btn_rerun.setVisible(has)
        self.btn_rerun.setEnabled(has and s.final is not None)
        if not has:
            self.lbl_ai.setText("The AI model is not installed yet. It is a one-time free download.")
        else:
            dev = s.ai.device_label if s.ai is not None and s.ai.loaded else "GPU (DirectML) if available, otherwise CPU"
            self.lbl_ai.setText(f"Model ready. Runs on: {dev}.")


# ============================================================================== Crop
class CropPage(QWidget):
    def __init__(self, state: AppState):
        super().__init__()
        self.state = state
        self._shown_base = None
        root = QHBoxLayout(self)
        root.setContentsMargins(14, 14, 14, 14)
        root.setSpacing(14)

        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 4, 0)
        lv.setSpacing(12)

        s1 = Section("Aspect ratio")
        self.cmb = QComboBox()
        self._ratios = [("Free", None), ("Original", "orig"), ("1 : 1", 1.0), ("3 : 4", 3 / 4), ("4 : 3", 4 / 3),
                        ("2 : 3", 2 / 3), ("3 : 2", 3 / 2), ("9 : 16", 9 / 16), ("16 : 9", 16 / 9)]
        for name, _ in self._ratios:
            self.cmb.addItem(name)
        s1.add(self.cmb)
        lv.addWidget(s1)

        s2 = Section("Region (pixels)")
        grid = QGridLayout()
        self.spins: Dict[str, QSpinBox] = {}
        for i, (key, text) in enumerate((("x", "X"), ("y", "Y"), ("w", "Width"), ("h", "Height"))):
            sp = QSpinBox()
            sp.setRange(0, 20000)
            sp.setKeyboardTracking(False)
            self.spins[key] = sp
            grid.addWidget(QLabel(text), i // 2, (i % 2) * 2)
            grid.addWidget(sp, i // 2, (i % 2) * 2 + 1)
        s2.add_layout(grid)
        self.lbl_result = _label("", "hint")
        s2.add(self.lbl_result)
        lv.addWidget(s2)

        s3 = Section("Orientation")
        g = QGridLayout()
        for i, (text, op) in enumerate((("Rotate left", "rot_ccw"), ("Rotate right", "rot_cw"),
                                        ("Flip horizontal", "flip_h"), ("Flip vertical", "flip_v"))):
            b = button(text)
            b.clicked.connect(lambda _=False, o=op: state.transform(o))
            g.addWidget(b, i // 2, i % 2)
        s3.add_layout(g)
        s3.add(_label("Flip horizontal is handy when you need a mirrored mould.", "hint", True))
        lv.addWidget(s3)

        row = QHBoxLayout()
        self.btn_reset = button("Reset")
        self.btn_apply = button("Apply crop", primary=True)
        row.addWidget(self.btn_reset)
        row.addWidget(self.btn_apply, 1)
        lv.addLayout(row)
        lv.addStretch(1)
        root.addWidget(_scroll(left, 360))

        self.view = CropWidget()
        frame = QFrame()
        frame.setObjectName("panel")
        fl = QVBoxLayout(frame)
        fl.setContentsMargins(6, 6, 6, 6)
        fl.addWidget(self.view)
        root.addWidget(frame, 1)

        self.cmb.currentIndexChanged.connect(self._aspect)
        self.view.cropChanged.connect(self._sync_spins)
        for sp in self.spins.values():
            sp.valueChanged.connect(self._spin_edited)
        self.btn_reset.clicked.connect(self.view.reset)
        self.btn_apply.clicked.connect(lambda: state.apply_crop(*self.view.crop_rect()))
        state.imageChanged.connect(self._refresh)

    def _refresh(self) -> None:
        s = self.state
        if s.base is not None and s.base is not self._shown_base:
            self._shown_base = s.base
            self.view.set_image(to_u8(s.base.rgb))
            self.cmb.blockSignals(True)
            self.cmb.setCurrentIndex(0)
            self.cmb.blockSignals(False)
            self.view.set_aspect(None)

    def _aspect(self) -> None:
        val = self._ratios[self.cmb.currentIndex()][1]
        if val == "orig":
            w, h = self.view.image_size()
            val = w / h if h else None
        self.view.set_aspect(val)

    def _sync_spins(self, x, y, w, h) -> None:
        for key, v in zip("xywh", (x, y, w, h)):
            sp = self.spins[key]
            sp.blockSignals(True)
            sp.setValue(v)
            sp.blockSignals(False)
        iw, ih = self.view.image_size()
        self.lbl_result.setText(f"Result: {w} × {h} px  (image {iw} × {ih})")
        self.btn_apply.setEnabled(not (x == 0 and y == 0 and w == iw and h == ih) or self.state.final is not self.state.base)

    def _spin_edited(self) -> None:
        self.view.set_crop(*(self.spins[k].value() for k in "xywh"))


# ============================================================================== Mesh
class MeshPage(QWidget):
    gotoCrop = Signal()
    exportRequested = Signal()

    def __init__(self, state: AppState, force_software: bool = False):
        super().__init__()
        self.state = state
        self._ctrl: Dict[str, QWidget] = {}
        root = QHBoxLayout(self)
        root.setContentsMargins(14, 14, 14, 14)
        root.setSpacing(14)

        root.addWidget(_scroll(self._build_left(), 345))

        centre = QVBoxLayout()
        centre.setSpacing(10)
        centre.addLayout(self._build_toolbar())
        self.vp = GLViewport(force_software=force_software)
        vf = QFrame()
        vf.setObjectName("panel")
        vl = QVBoxLayout(vf)
        vl.setContentsMargins(2, 2, 2, 2)
        vl.addWidget(self.vp)
        centre.addWidget(vf, 1)
        root.addLayout(centre, 1)

        root.addWidget(_scroll(self._build_right(), 265))

        state.imageChanged.connect(self._on_image)
        state.resultChanged.connect(self._on_result)
        state.paramsChanged.connect(self.sync_from_params)
        state.aiChanged.connect(self._refresh_stats)
        state.depthChanged.connect(self._refresh_stats)
        self.sync_from_params()
        self._refresh_stats()

    # ----------------------------------------------------------------- left
    def _slider(self, sec: Section, label, field, lo, hi, step, dec, tip=""):
        w = ParamSlider(label, lo, hi, getattr(DEFAULTS, field), step, dec, tip)
        w.valueChanged.connect(lambda v, f=field: self.state.set_param(f, v))
        sec.add(w)
        self._ctrl[field] = w

    def _check(self, sec: Section, text, field, tip=""):
        c = QCheckBox(text)
        c.setToolTip(tip)
        c.toggled.connect(lambda v, f=field: self.state.set_param(f, v))
        sec.add(c)
        self._ctrl[field] = c

    def _build_left(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 4, 0)
        v.setSpacing(12)

        s = Section("Overall size")
        for label, field, lo, hi, step, tip in (
                ("Width (X)", "width_mm", 5, 2000, 1.0, "Panel width. Height follows the image shape."),
                ("Relief height (Z)", "relief_height_mm", 0.1, 100, 0.5, "How high the relief rises above the base."),
                ("Base thickness", "base_mm", 0, 100, 0.5, "Solid plate under the relief.")):
            r = SpinRow(label, lo, hi, getattr(DEFAULTS, field), step, 2, " mm", tip)
            r.valueChanged.connect(lambda val, f=field: self.state.set_param(f, val))
            s.add(r)
            self._ctrl[field] = r
        self.btn_neg = button("Negative mode (mould / intaglio)", toggle=True,
                              tip="Inverts the heights: raised parts become recessed.")
        self.btn_neg.toggled.connect(lambda on: self.state.set_param("negative", on))
        s.add(self.btn_neg)
        self._ctrl["negative"] = self.btn_neg
        self.lbl_dims = _label("", "hint", True)
        s.add(self.lbl_dims)
        v.addWidget(s)

        s = Section("Depth filter")
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItem("Detail separation (High-Pass)", ProcessingMode.HIGH_PASS.value)
        self.cmb_mode.addItem("Direct depth", ProcessingMode.DIRECT.value)
        self.cmb_mode.currentIndexChanged.connect(lambda _: self.state.set_param("mode", self.cmb_mode.currentData()))
        s.add(_label("Processing mode"))
        s.add(self.cmb_mode)
        self._ctrl["mode"] = self.cmb_mode
        self._check(s, "Cut mask: force background to zero", "use_mask",
                    "Finds the plain background around your subject and flattens it.")
        self._slider(s, "Mask tolerance", "mask_tolerance", 0, 120, 1, 0, "How different from the background colour a pixel must be to count as subject.")
        self._slider(s, "Background trim", "bg_trim", 0, 100, 1, 0, "Shaves off the lowest values (0-255 scale).")
        self._slider(s, "Floor lift (mm)", "floor_lift_mm", 0, 2, 0.05, 2, "Lowest relief surface sits this far above the base.")
        self._check(s, "Use detail layer only", "detail_only", "Fine engraving from the detail layer alone.")
        self._slider(s, "High-pass radius", "highpass_radius", 1, 60, 1, 0, "Size of the detail that is kept.")
        self._slider(s, "Detail strength", "detail_strength", 0, 1.5, 0.05, 2, "How strongly fine detail is added on top of the depth.")
        self._slider(s, "Base smooth", "base_smooth", 0, 30, 0.5, 1, "Blurs the depth. Calms noisy photos.")
        self._slider(s, "Groove deepen", "groove_deepen", 0, 2, 0.05, 2, "Digs creases and dark lines deeper.")
        self._check(s, "Invert depth (dark = high)", "invert_depth")
        v.addWidget(s)

        s = Section("3D levels")
        self._slider(s, "Black point", "black_point", 0, 254, 1, 0)
        self._slider(s, "Gamma", "gamma", 0.2, 4, 0.05, 2, "Above 1 lifts the mid-tones.")
        self._slider(s, "White point", "white_point", 1, 255, 1, 0)
        v.addWidget(s)

        s = Section("Mesh detail")
        self.cmb_level = QComboBox()
        names = {1: "Level 1 (2M triangles)", 2: "Level 2 (1M triangles)", 3: "Level 3 (500k triangles)",
                 4: "Level 4 (250k triangles)", 5: "Level 5 (100k triangles)"}
        for k in sorted(MESH_LEVELS):
            self.cmb_level.addItem(names[k], k)
        self.cmb_level.currentIndexChanged.connect(lambda _: (self.state.set_param("mesh_level", self.cmb_level.currentData()),
                                                              self._refresh_stats()))
        s.add(self.cmb_level)
        self._ctrl["mesh_level"] = self.cmb_level
        self.btn_update = button("Update 3D mesh", primary=True)
        self.btn_update.clicked.connect(self.state.update_mesh_full)
        s.add(self.btn_update)
        s.add(_label(f"The live preview never goes finer than level {PREVIEW_MIN_LEVEL} so sliders stay smooth. "
                     "Update shows the exact mesh you will export.", "hint", True))
        v.addWidget(s)

        self.btn_defaults = button("Reset settings")
        self.btn_defaults.clicked.connect(self.state.reset_params)
        v.addWidget(self.btn_defaults)
        v.addStretch(1)
        return w

    # -------------------------------------------------------------- toolbar
    def _build_toolbar(self) -> QHBoxLayout:
        row = QHBoxLayout()
        row.setSpacing(6)
        for text, tip, fn in (("X+90", "Rotate the view 90° around X", lambda: self.vp.rotate_x(90)),
                              ("X−90", "Rotate the view -90° around X", lambda: self.vp.rotate_x(-90)),
                              ("Z+90", "Rotate the view 90° around Z", lambda: self.vp.rotate_z(90)),
                              ("Z−90", "Rotate the view -90° around Z", lambda: self.vp.rotate_z(-90)),
                              ("Reset view", "Back to the top view", lambda: self.vp.reset_view())):
            b = button(text, chip=True, tip=tip)
            b.clicked.connect(lambda _=False, f=fn: f())
            row.addWidget(b)
        row.addStretch(1)
        grp = QButtonGroup(self)
        for text, mode in (("Shaded", "shaded"), ("Normal", "normal"), ("Texture", "texture")):
            b = button(text, chip=True, toggle=True)
            b.setChecked(mode == "shaded")
            grp.addButton(b)
            b.clicked.connect(lambda _=False, m=mode: self.vp.set_mode(m))
            row.addWidget(b)
        self.btn_wire = button("Wire", chip=True, toggle=True, tip="Show the triangle mesh")
        self.btn_wire.toggled.connect(self.vp.set_wire if hasattr(self, "vp") else (lambda on: self.vp.set_wire(on)))
        row.addWidget(self.btn_wire)
        return row

    # ---------------------------------------------------------------- right
    def _build_right(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 4, 0)
        v.setSpacing(12)

        s = Section("Final 2D input")
        self.thumb_in = ImageThumb("No image", 110)
        s.add(self.thumb_in)
        b = button("Edit crop or resize")
        b.clicked.connect(self.gotoCrop)
        s.add(b)
        v.addWidget(s)

        s = Section("Final mixed depth")
        self.thumb_depth = ImageThumb("No depth yet", 110)
        s.add(self.thumb_depth)
        v.addWidget(s)

        s = Section("Mesh statistics")
        g = QGridLayout()
        g.setHorizontalSpacing(10)
        self.stat: Dict[str, QLabel] = {}
        for i, (key, text) in enumerate((("verts", "Vertices"), ("faces", "Faces"), ("size", "File size (est.)"),
                                         ("mm", "Size (mm)"), ("grid", "Grid"))):
            g.addWidget(_label(text, "muted"), i, 0)
            lb = _label("-", "statValue")
            lb.setAlignment(Qt.AlignRight)
            g.addWidget(lb, i, 1)
            self.stat[key] = lb
        s.add_layout(g)
        self.lbl_showing = _label("", "hint", True)
        s.add(self.lbl_showing)
        v.addWidget(s)

        s = Section("AI engine and memory")
        g = QGridLayout()
        g.addWidget(_label("Engine", "muted"), 0, 0)
        self.lbl_engine = _label("-", "statValue")
        self.lbl_engine.setAlignment(Qt.AlignRight)
        g.addWidget(self.lbl_engine, 0, 1)
        g.addWidget(_label("Memory in use", "muted"), 1, 0)
        self.lbl_mem = _label("-", "statValue")
        self.lbl_mem.setAlignment(Qt.AlignRight)
        g.addWidget(self.lbl_mem, 1, 1)
        s.add_layout(g)
        row = QHBoxLayout()
        b1, b2 = button("Free VRAM"), button("Clean up")
        b1.setToolTip("Unloads the AI model from GPU memory.")
        b2.setToolTip("Unloads the AI model and frees cached data.")
        b1.clicked.connect(self.state.free_vram)
        b2.clicked.connect(self.state.clean_up)
        row.addWidget(b1)
        row.addWidget(b2)
        s.add_layout(row)
        v.addWidget(s)

        s = Section("Export")
        self.cmb_fmt = QComboBox()
        self.cmb_fmt.addItem("STL, binary (recommended)")
        s.add(self.cmb_fmt)
        self.btn_export = button("Export file", primary=True)
        self.btn_export.clicked.connect(self.exportRequested)
        s.add(self.btn_export)
        b = button("Save depth map (PNG)")
        b.clicked.connect(self._save_depth)
        s.add(b)
        v.addWidget(s)
        v.addStretch(1)
        return w

    # ---------------------------------------------------------------- logic
    def _save_depth(self) -> None:
        from PySide6.QtWidgets import QFileDialog
        if self.state.result is None:
            self.state.errorRaised.emit("Nothing to save", "Open an image first.")
            return
        stem = self.state.source_path.stem if self.state.source_path else "depth"
        path, _ = QFileDialog.getSaveFileName(self, "Save depth map", f"{stem}_depth.png", "PNG image (*.png)")
        if path:
            self.state.export_depth_png(path if path.lower().endswith(".png") else path + ".png")

    def sync_from_params(self) -> None:
        p = self.state.params
        for field, w in self._ctrl.items():
            val = getattr(p, field)
            if isinstance(w, (ParamSlider, SpinRow)):
                w.setValue(float(val))
            elif isinstance(w, (QCheckBox,)) or hasattr(w, "setChecked"):
                w.blockSignals(True)
                w.setChecked(bool(val))
                w.blockSignals(False)
            elif isinstance(w, QComboBox):
                data = val.value if isinstance(val, ProcessingMode) else val
                idx = w.findData(data)
                w.blockSignals(True)
                w.setCurrentIndex(max(0, idx))
                w.blockSignals(False)
        self._update_dims()
        self._refresh_stats()

    def _update_dims(self) -> None:
        s, p = self.state, self.state.params
        if s.final is None:
            self.lbl_dims.setText("")
            return
        y = p.width_mm * s.final.height / s.final.width
        self.lbl_dims.setText(f"Panel {p.width_mm:.1f} × {y:.1f} mm, total height {p.base_mm + p.relief_height_mm:.2f} mm")

    def _on_image(self) -> None:
        s = self.state
        if s.final is None:
            return
        self.thumb_in.set_array(to_u8(s.final.rgb))
        self.thumb_depth.set_array(None)
        self.vp.set_texture(s.final.rgb)
        self._update_dims()
        self._refresh_stats()

    def _on_result(self) -> None:
        s, r = self.state, self.state.result
        if r is None:
            return
        self.vp.set_mesh(r.mesh, r.z_mm)
        self.vp.set_caption(f"{'Full detail' if s.result_full else 'Live preview'}, {r.stats.faces:,} triangles")
        self.thumb_depth.set_array(to_u8(r.depth))
        self._update_dims()
        self._refresh_stats()

    def _refresh_stats(self) -> None:
        s, p = self.state, self.state.params
        if s.final is None:
            for lb in self.stat.values():
                lb.setText("-")
        else:
            nx, ny, verts, faces, size = estimate_mesh_stats(s.final.width, s.final.height, p.mesh_level)
            y = p.width_mm * s.final.height / s.final.width
            self.stat["verts"].setText(f"{verts:,}")
            self.stat["faces"].setText(f"{faces:,}")
            self.stat["size"].setText(f"{size / 1e6:.1f} MB")
            self.stat["mm"].setText(f"{p.width_mm:.1f} × {y:.1f} × {p.base_mm + p.relief_height_mm:.2f}")
            self.stat["grid"].setText(f"{nx} × {ny}")
            r = s.result
            if r is not None:
                self.lbl_showing.setText("Viewport shows the full export mesh." if s.result_full else
                                         f"Numbers above are for the export. The viewport shows a live preview ({r.stats.faces:,} triangles).")
        ai = s.ai
        self.lbl_engine.setText(ai.device_label if ai is not None and ai.loaded else ("Ready" if s.model_path else "No AI model"))
        self.lbl_mem.setText(f"{s.memory_mb():.0f} MB")
