"""Interactive crop rectangle over an image (drag corners/edges, move, optional aspect lock)."""
from __future__ import annotations

from typing import Optional, Tuple

import numpy as np
from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QImage, QPainter, QPen
from PySide6.QtWidgets import QWidget

from . import theme
from .widgets import array_to_qimage

MIN_SIZE = 16.0
HANDLE = 10.0


class CropWidget(QWidget):
    cropChanged = Signal(int, int, int, int)           # x, y, w, h in image pixels

    def __init__(self):
        super().__init__()
        self.setMinimumSize(360, 300)
        self.setMouseTracking(True)
        self._img: Optional[QImage] = None
        self._l = self._t = self._r = self._b = 0.0
        self._aspect: Optional[float] = None
        self._drag: Optional[str] = None
        self._start = (0.0, 0.0, 0.0, 0.0)
        self._grab = QPointF()

    # --------------------------------------------------------------- public
    def set_image(self, arr: Optional[np.ndarray]) -> None:
        if arr is None:
            self._img = None
        else:
            self._img = array_to_qimage(arr)
            self._l, self._t, self._r, self._b = 0.0, 0.0, float(self._img.width()), float(self._img.height())
            self._apply_aspect_to_rect()
        self.update()
        self._emit()

    def image_size(self) -> Tuple[int, int]:
        return (self._img.width(), self._img.height()) if self._img else (0, 0)

    def crop_rect(self) -> Tuple[int, int, int, int]:
        x, y = int(round(self._l)), int(round(self._t))
        return x, y, max(1, int(round(self._r)) - x), max(1, int(round(self._b)) - y)

    def set_crop(self, x: float, y: float, w: float, h: float) -> None:
        if not self._img:
            return
        iw, ih = self._img.width(), self._img.height()
        w, h = max(MIN_SIZE, min(w, iw)), max(MIN_SIZE, min(h, ih))
        x, y = min(max(0.0, x), iw - w), min(max(0.0, y), ih - h)
        self._l, self._t, self._r, self._b = x, y, x + w, y + h
        self.update()
        self._emit()

    def reset(self) -> None:
        if self._img:
            self._l, self._t, self._r, self._b = 0.0, 0.0, float(self._img.width()), float(self._img.height())
            self._apply_aspect_to_rect()
            self.update()
            self._emit()

    def set_aspect(self, ratio: Optional[float]) -> None:
        self._aspect = ratio
        self._apply_aspect_to_rect()
        self.update()
        self._emit()

    # -------------------------------------------------------------- geometry
    def _transform(self):
        iw, ih = self._img.width(), self._img.height()
        m = 18.0
        s = min((self.width() - 2 * m) / iw, (self.height() - 2 * m) / ih)
        ox, oy = (self.width() - iw * s) / 2.0, (self.height() - ih * s) / 2.0
        return s, ox, oy

    def _to_view(self, x: float, y: float) -> QPointF:
        s, ox, oy = self._transform()
        return QPointF(ox + x * s, oy + y * s)

    def _to_img(self, p: QPointF) -> QPointF:
        s, ox, oy = self._transform()
        return QPointF((p.x() - ox) / s, (p.y() - oy) / s)

    def _apply_aspect_to_rect(self) -> None:
        if not self._img or not self._aspect:
            return
        cx, cy = (self._l + self._r) / 2, (self._t + self._b) / 2
        w, h = self._r - self._l, self._b - self._t
        if w / h > self._aspect:
            w = h * self._aspect
        else:
            h = w / self._aspect
        self._l, self._r, self._t, self._b = cx - w / 2, cx + w / 2, cy - h / 2, cy + h / 2

    def _emit(self) -> None:
        if self._img:
            self.cropChanged.emit(*self.crop_rect())

    def _handles(self):
        l, t, r, b = self._l, self._t, self._r, self._b
        cx, cy = (l + r) / 2, (t + b) / 2
        return {"tl": (l, t), "t": (cx, t), "tr": (r, t), "r": (r, cy),
                "br": (r, b), "b": (cx, b), "bl": (l, b), "l": (l, cy)}

    def _hit(self, pos: QPointF) -> Optional[str]:
        for name, (x, y) in self._handles().items():
            v = self._to_view(x, y)
            if abs(v.x() - pos.x()) <= HANDLE and abs(v.y() - pos.y()) <= HANDLE:
                return name
        a, b = self._to_view(self._l, self._t), self._to_view(self._r, self._b)
        if QRectF(a, b).contains(pos):
            return "move"
        return None

    # ----------------------------------------------------------------- mouse
    def mousePressEvent(self, e):
        if not self._img or e.button() != Qt.LeftButton:
            return
        self._drag = self._hit(e.position())
        self._start = (self._l, self._t, self._r, self._b)
        self._grab = self._to_img(e.position())

    def mouseMoveEvent(self, e):
        if not self._img:
            return
        if not self._drag:
            h = self._hit(e.position())
            cur = {"tl": Qt.SizeFDiagCursor, "br": Qt.SizeFDiagCursor, "tr": Qt.SizeBDiagCursor,
                   "bl": Qt.SizeBDiagCursor, "t": Qt.SizeVerCursor, "b": Qt.SizeVerCursor,
                   "l": Qt.SizeHorCursor, "r": Qt.SizeHorCursor, "move": Qt.SizeAllCursor}.get(h, Qt.ArrowCursor)
            self.setCursor(cur)
            return
        iw, ih = self._img.width(), self._img.height()
        p = self._to_img(e.position())
        px, py = min(max(p.x(), 0.0), iw), min(max(p.y(), 0.0), ih)
        l, t, r, b = self._start
        if self._drag == "move":
            dx, dy = p.x() - self._grab.x(), p.y() - self._grab.y()
            w, h = r - l, b - t
            nl = min(max(l + dx, 0.0), iw - w)
            nt = min(max(t + dy, 0.0), ih - h)
            self._l, self._t, self._r, self._b = nl, nt, nl + w, nt + h
        else:
            self._resize(self._drag, px, py, l, t, r, b, iw, ih)
        self.update()
        self._emit()

    def mouseReleaseEvent(self, e):
        self._drag = None

    def _resize(self, hnd, px, py, l, t, r, b, iw, ih) -> None:
        nl, nt, nr, nb = l, t, r, b
        if "l" in hnd:
            nl = min(px, r - MIN_SIZE)
        if "r" in hnd:
            nr = max(px, l + MIN_SIZE)
        if "t" in hnd:
            nt = min(py, b - MIN_SIZE)
        if "b" in hnd:
            nb = max(py, t + MIN_SIZE)
        if self._aspect:
            a = self._aspect
            w, h = nr - nl, nb - nt
            if hnd in ("l", "r"):
                h = w / a
                cy = (t + b) / 2
                nt, nb = cy - h / 2, cy + h / 2
                anchor = (r if hnd == "l" else l, cy)
            elif hnd in ("t", "b"):
                w = h * a
                cx = (l + r) / 2
                nl, nr = cx - w / 2, cx + w / 2
                anchor = (cx, b if hnd == "t" else t)
            else:
                if w / a > h:
                    h = w / a
                else:
                    w = h * a
                if "l" in hnd:
                    nl = r - w
                else:
                    nr = l + w
                if "t" in hnd:
                    nt = b - h
                else:
                    nb = t + h
                anchor = (r if "l" in hnd else l, b if "t" in hnd else t)
            # shrink about the anchor until the rectangle fits inside the image
            s = 1.0
            for e_, a_, lim in ((nl, anchor[0], 0.0), (nr, anchor[0], iw), (nt, anchor[1], 0.0), (nb, anchor[1], ih)):
                if (lim == 0.0 and e_ < 0.0) or (lim != 0.0 and e_ > lim):
                    s = min(s, (lim - a_) / (e_ - a_))
            if s < 1.0:
                nl, nr = anchor[0] + (nl - anchor[0]) * s, anchor[0] + (nr - anchor[0]) * s
                nt, nb = anchor[1] + (nt - anchor[1]) * s, anchor[1] + (nb - anchor[1]) * s
        self._l, self._t, self._r, self._b = nl, nt, nr, nb

    # ----------------------------------------------------------------- paint
    def paintEvent(self, _):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor(theme.BG_DEEP))
        if not self._img:
            p.setPen(QColor(theme.MUTED))
            p.drawText(self.rect(), Qt.AlignCenter, "Open an image to crop it")
            return
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        s, ox, oy = self._transform()
        iw, ih = self._img.width(), self._img.height()
        full = QRectF(ox, oy, iw * s, ih * s)
        p.drawImage(full, self._img)
        a, b = self._to_view(self._l, self._t), self._to_view(self._r, self._b)
        crop = QRectF(a, b)
        dim = QColor(5, 8, 12, 165)
        for r in (QRectF(full.left(), full.top(), full.width(), crop.top() - full.top()),
                  QRectF(full.left(), crop.bottom(), full.width(), full.bottom() - crop.bottom()),
                  QRectF(full.left(), crop.top(), crop.left() - full.left(), crop.height()),
                  QRectF(crop.right(), crop.top(), full.right() - crop.right(), crop.height())):
            p.fillRect(r, dim)
        p.setPen(QPen(QColor(255, 255, 255, 70), 1))
        for i in (1, 2):
            p.drawLine(QPointF(crop.left() + crop.width() * i / 3, crop.top()), QPointF(crop.left() + crop.width() * i / 3, crop.bottom()))
            p.drawLine(QPointF(crop.left(), crop.top() + crop.height() * i / 3), QPointF(crop.right(), crop.top() + crop.height() * i / 3))
        p.setPen(QPen(QColor(theme.ACCENT), 2))
        p.drawRect(crop)
        p.setBrush(QColor(theme.ACCENT))
        p.setPen(Qt.NoPen)
        for x, y in self._handles().values():
            v = self._to_view(x, y)
            p.drawRect(QRectF(v.x() - 4, v.y() - 4, 8, 8))
        p.end()
