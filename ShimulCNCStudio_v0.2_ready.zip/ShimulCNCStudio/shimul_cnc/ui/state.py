"""Application state + background job queue. The UI only talks to this object."""
from __future__ import annotations

import gc
import json
import logging
import time
from dataclasses import replace
from pathlib import Path
from typing import Callable, Optional

import numpy as np
from PIL import Image
from PySide6.QtCore import QObject, QThread, QTimer, Signal

from .. import sysinfo
from ..ai import DepthAnythingOnnx, DownloadCancelled, ModelError, download_model, find_model, import_model
from ..core import (GrayscaleDepth, LoadedImage, ReliefParams, analyse, load_image, render_relief,
                    write_binary_stl)
from ..core.pipeline import Analysis, ReliefResult

log = logging.getLogger("shimul")
PREVIEW_MIN_LEVEL = 3        # live preview is never finer than level 3 (keeps sliders responsive)


class Job(QThread):
    done = Signal(object)
    failed = Signal(str)
    progress = Signal(float, str)

    def __init__(self, fn: Callable, parent=None):
        super().__init__(parent)
        self._fn = fn

    def run(self):
        try:
            res = self._fn(lambda f, m: self.progress.emit(float(f), str(m)))
        except DownloadCancelled:
            self.failed.emit("Cancelled")
        except Exception as e:
            log.exception("Job failed")
            self.failed.emit(str(e) or e.__class__.__name__)
        else:
            self.done.emit(res)


class AppState(QObject):
    imageChanged = Signal()
    depthChanged = Signal()
    resultChanged = Signal()
    paramsChanged = Signal()          # params were changed by the state itself (preset, reset, clamping)
    aiChanged = Signal()
    statusChanged = Signal(str, str)  # kind (ready|busy|error), text
    progressChanged = Signal(float, str)
    errorRaised = Signal(str, str)
    infoRaised = Signal(str, str)
    exported = Signal(str, int)
    sysinfoReady = Signal(str)
    modelNeeded = Signal()

    def __init__(self):
        super().__init__()
        self.params = ReliefParams()
        self.depth_mode = "gray"                 # "ai" | "gray"
        self.source_path: Optional[Path] = None
        self.base: Optional[LoadedImage] = None  # after rotate / flip
        self.final: Optional[LoadedImage] = None  # after crop = engine input
        self.analysis: Optional[Analysis] = None
        self.result: Optional[ReliefResult] = None
        self.result_full = False
        self.model_path: Optional[Path] = find_model()
        self.ai: Optional[DepthAnythingOnnx] = None
        self.elapsed = 0.0
        self._gen = 0
        self._queue: list = []
        self._job: Optional[Job] = None
        self._cancel_download = False
        self._misc: list = []
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(lambda: self._submit_preview(False))
        self.depth_mode = "ai" if self.model_path else "gray"

    # ------------------------------------------------------------ job queue
    def submit(self, kind: str, fn: Callable, on_done: Callable, label: str = "",
               on_fail: Optional[Callable] = None) -> None:
        self._queue = [q for q in self._queue if q[0] != kind]       # newest request of a kind wins
        self._queue.append((kind, fn, on_done, label, on_fail))
        self._pump()

    def _pump(self) -> None:
        if self._job is not None:
            return
        if not self._queue:
            self.statusChanged.emit("ready", "Ready")
            self.progressChanged.emit(-1.0, "")
            return
        kind, fn, on_done, label, on_fail = self._queue.pop(0)
        job = Job(fn, self)
        self._job = job
        self.statusChanged.emit("busy", label or kind)
        self.progressChanged.emit(0.0, label)
        job.progress.connect(self.progressChanged.emit)
        job.done.connect(lambda r: self._finish(job, on_done, r))
        job.failed.connect(lambda m: self._fail(job, on_fail, m, kind))
        job.start()

    def _release(self, job: Job) -> None:
        job.wait()
        job.deleteLater()
        self._job = None

    def _finish(self, job: Job, on_done: Callable, res) -> None:
        self._release(job)
        try:
            on_done(res)
        except Exception as e:
            log.exception("on_done failed")
            self.errorRaised.emit("Unexpected error", str(e))
        self._pump()

    def _fail(self, job: Job, on_fail: Optional[Callable], msg: str, kind: str) -> None:
        self._release(job)
        self.statusChanged.emit("error", msg[:120])
        if on_fail:
            on_fail(msg)
        elif msg != "Cancelled":
            self.errorRaised.emit("Something went wrong", msg)
        self._pump()

    # ----------------------------------------------------------------- image
    def open_image(self, path) -> None:
        img = load_image(path)
        self.source_path = Path(path)
        self.base = img
        self._set_final(img)

    def _set_final(self, img: LoadedImage) -> None:
        self.final = img
        self._gen += 1
        self.analysis = None
        self.result = None
        self.imageChanged.emit()
        self._ensure_analysis()

    def transform(self, op: str) -> None:
        if self.base is None:
            return
        rgb, alpha = self.base.rgb, self.base.alpha
        fns = {"rot_cw": lambda a: np.rot90(a, -1), "rot_ccw": lambda a: np.rot90(a, 1),
               "flip_h": lambda a: a[:, ::-1], "flip_v": lambda a: a[::-1]}
        f = fns[op]
        self.base = LoadedImage(np.ascontiguousarray(f(rgb)), None if alpha is None else np.ascontiguousarray(f(alpha)),
                                self.base.source)
        self._set_final(self.base)

    def apply_crop(self, x: int, y: int, w: int, h: int) -> None:
        if self.base is None:
            return
        H, W = self.base.rgb.shape[:2]
        x, y = max(0, min(x, W - 2)), max(0, min(y, H - 2))
        w, h = max(2, min(w, W - x)), max(2, min(h, H - y))
        a = self.base.alpha
        self._set_final(LoadedImage(np.ascontiguousarray(self.base.rgb[y:y + h, x:x + w]),
                                    None if a is None else np.ascontiguousarray(a[y:y + h, x:x + w]),
                                    self.base.source))

    def reset_crop(self) -> None:
        if self.base is not None:
            self._set_final(self.base)

    # ----------------------------------------------------------------- depth
    def set_depth_mode(self, mode: str) -> None:
        if mode == "ai" and self.model_path is None:
            self.aiChanged.emit()
            self.modelNeeded.emit()
            return
        if mode == self.depth_mode:
            return
        self.depth_mode = mode
        self.aiChanged.emit()
        self._gen += 1
        self.analysis = None
        self._ensure_analysis()

    def _ensure_analysis(self) -> None:
        if self.final is None:
            return
        if self.depth_mode == "ai" and self.model_path is not None:
            self.run_ai_depth()
            return
        self.analysis = analyse(self.final, GrayscaleDepth())
        self.depthChanged.emit()
        self.schedule_preview(0)

    def run_ai_depth(self) -> None:
        if self.final is None or self.model_path is None:
            return
        final, gen = self.final, self._gen
        if self.ai is None or self.ai.model_path != self.model_path:
            self.ai = DepthAnythingOnnx(self.model_path)
        ai = self.ai

        def done(analysis):
            if gen != self._gen:
                return
            self.analysis = analysis
            self.depthChanged.emit()
            self.aiChanged.emit()
            self.schedule_preview(0)

        def fail(msg):
            if gen != self._gen:
                return
            self.depth_mode = "gray"
            self.aiChanged.emit()
            self.errorRaised.emit("AI depth failed", f"{msg}\n\nSwitched to grayscale depth so you can keep working.")
            self._ensure_analysis()

        self.submit("depth", lambda prog: analyse(final, ai, prog), done, "Running AI depth", fail)

    # ------------------------------------------------------------ AI model
    def download_model(self) -> None:
        self._cancel_download = False

        def done(path):
            self.model_path = path
            self.aiChanged.emit()
            self.infoRaised.emit("AI model ready", "The AI model was downloaded. AI depth is now available.")
            self.set_depth_mode("ai")

        def fail(msg):
            if msg != "Cancelled":
                self.errorRaised.emit("Download failed", msg)

        self.submit("download", lambda prog: download_model(prog, cancel=lambda: self._cancel_download),
                    done, "Downloading AI model", fail)

    def cancel_download(self) -> None:
        self._cancel_download = True

    def import_model_file(self, path) -> None:
        try:
            self.model_path = import_model(Path(path))
        except ModelError as e:
            self.errorRaised.emit("Model import failed", str(e))
            return
        self.ai = None
        self.aiChanged.emit()
        self.set_depth_mode("ai")

    def free_vram(self) -> None:
        if self.ai is not None:
            self.ai.unload()
        gc.collect()
        self.aiChanged.emit()

    def clean_up(self) -> None:
        self.free_vram()
        self.result = None if not self.result_full else self.result
        gc.collect()
        self.aiChanged.emit()

    def memory_mb(self) -> float:
        total = 0
        if self.ai is not None and self.ai.loaded and self.model_path is not None:
            try:
                total += self.model_path.stat().st_size
            except OSError:
                pass
        arrays = []
        if self.analysis is not None:
            arrays += [self.analysis.depth, self.analysis.image.rgb]
        if self.result is not None:
            arrays += [self.result.depth, self.result.z_mm, self.result.mesh.vertices, self.result.mesh.faces]
        total += sum(a.nbytes for a in arrays)
        return total / 1e6

    # ---------------------------------------------------------------- params
    def set_param(self, name: str, value) -> None:
        setattr(self.params, name, type(getattr(self.params, name))(value) if not isinstance(getattr(self.params, name), bool) else bool(value))
        if self._normalise():
            self.paramsChanged.emit()
        self.schedule_preview(150)

    def _normalise(self) -> bool:
        p, changed = self.params, False
        if p.black_point >= p.white_point:
            if p.white_point < 255 and p.black_point < 254:
                p.white_point = p.black_point + 1
            else:
                p.black_point = p.white_point - 1
            changed = True
        if p.floor_lift_mm >= p.relief_height_mm:
            p.floor_lift_mm = max(0.0, round(p.relief_height_mm - 0.05, 2))
            changed = True
        if p.base_mm + p.floor_lift_mm < 0.05:
            p.base_mm = 0.05
            changed = True
        return changed

    def reset_params(self) -> None:
        keep = self.params.mesh_level
        self.params = ReliefParams(mesh_level=keep)
        self.paramsChanged.emit()
        self.schedule_preview(0)

    def save_preset(self, path) -> None:
        data = {"params": self.params.to_dict(), "depth_mode": self.depth_mode}
        Path(path).write_text(json.dumps(data, indent=2), encoding="utf-8")

    def load_preset(self, path) -> None:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        self.params = ReliefParams.from_dict(data.get("params", data))
        self.paramsChanged.emit()
        self.schedule_preview(0)

    # --------------------------------------------------------------- results
    def schedule_preview(self, delay_ms: int = 150) -> None:
        self._timer.start(max(0, delay_ms))

    def update_mesh_full(self) -> None:
        self._submit_preview(True)

    def _submit_preview(self, full: bool) -> None:
        if self.final is None or self.analysis is None:
            return
        gen, analysis = self._gen, self.analysis
        p = replace(self.params)
        if not full:
            p = replace(p, mesh_level=max(p.mesh_level, PREVIEW_MIN_LEVEL))

        def done(res):
            if gen != self._gen:
                return
            self.result, self.result_full, self.elapsed = res, full, res.stats.elapsed_s
            self.resultChanged.emit()

        self.submit("preview", lambda prog: render_relief(analysis, p, progress=prog), done,
                    "Building full-detail mesh" if full else "Updating 3D preview")

    # ---------------------------------------------------------------- export
    def export_stl(self, path) -> None:
        if self.analysis is None:
            self.errorRaised.emit("Nothing to export", "Open an image first.")
            return
        analysis, p, path = self.analysis, replace(self.params), str(path)

        def fn(prog):
            t0 = time.perf_counter()
            res = render_relief(analysis, p, progress=lambda f, m: prog(f * 0.4, m))
            size = write_binary_stl(path, res.mesh, progress=lambda f, m: prog(0.4 + 0.6 * f, m))
            return path, size, time.perf_counter() - t0

        def done(r):
            self.elapsed = r[2]
            self.exported.emit(r[0], r[1])

        self.submit("export", fn, done, "Exporting STL")

    def export_depth_png(self, path) -> None:
        if self.result is None:
            self.errorRaised.emit("Nothing to export", "No depth map yet.")
            return
        d16 = (np.clip(self.result.depth, 0, 1) * 65535 + 0.5).astype(np.uint16)
        Image.fromarray(d16).save(str(path), format="PNG")
        self.infoRaised.emit("Depth map saved", f"Saved 16-bit depth map:\n{path}")

    # ------------------------------------------------------------------ misc
    def detect_hardware(self) -> None:
        j = Job(lambda prog: sysinfo.describe(), self)
        j.done.connect(self.sysinfoReady.emit)
        j.start()
        self._misc.append(j)

    def shutdown(self) -> None:
        """Stop background work before the window closes."""
        self._queue.clear()
        self._cancel_download = True
        job = self._job
        if job is not None and job.isRunning() and not job.wait(5000):
            job.terminate()
            job.wait(1000)
