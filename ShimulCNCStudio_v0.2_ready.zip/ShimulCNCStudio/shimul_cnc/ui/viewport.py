"""OpenGL 3D viewport: orbit / pan / zoom, shaded, wireframe, normal-map and texture views.

If OpenGL cannot start on a machine, the viewport falls back to a shaded 2D preview
so the rest of the program keeps working.
"""
from __future__ import annotations

import math
from typing import Optional

import numpy as np
from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QImage, QPainter, QPen, QSurfaceFormat
from PySide6.QtOpenGLWidgets import QOpenGLWidget
from PySide6.QtWidgets import QWidget

try:                                    # PyOpenGL is optional at import time
    from OpenGL import GL as gl
except Exception:                       # pragma: no cover
    gl = None

from ..core.preview import hillshade
from . import theme
from .widgets import array_to_qimage

VERT = """#version 130
in vec3 aPos;
uniform mat4 uMVP;
uniform mat4 uMV;
out vec3 vPosW;
out vec3 vPosV;
void main() {
    vPosW = aPos;
    vPosV = (uMV * vec4(aPos, 1.0)).xyz;
    gl_Position = uMVP * vec4(aPos, 1.0);
}
"""

FRAG = """#version 130
in vec3 vPosW;
in vec3 vPosV;
uniform int uMode;            // 0 clay, 1 normal map, 2 texture, 3 wire colour
uniform sampler2D uTex;
uniform vec2 uSize;
uniform vec3 uLight;
out vec4 fragColor;
void main() {
    if (uMode == 3) { fragColor = vec4(0.96, 0.70, 0.22, 0.28); return; }   // translucent amber lines
    vec3 nW = normalize(cross(dFdx(vPosW), dFdy(vPosW)));
    vec3 nV = normalize(cross(dFdx(vPosV), dFdy(vPosV)));
    if (uMode == 1) { fragColor = vec4(nW * 0.5 + 0.5, 1.0); return; }
    float diff = max(dot(nV, normalize(uLight)), 0.0);
    vec3 base = vec3(0.80, 0.81, 0.84);
    if (uMode == 2 && nW.z > 0.3) {
        vec2 uv = vec2(vPosW.x / uSize.x, 1.0 - vPosW.y / uSize.y);
        base = texture(uTex, uv).rgb;
    }
    fragColor = vec4(base * (0.26 + 0.80 * diff), 1.0);
}
"""


def _perspective(fov_deg: float, aspect: float, near: float, far: float) -> np.ndarray:
    f = 1.0 / math.tan(math.radians(fov_deg) / 2.0)
    m = np.zeros((4, 4), np.float32)
    m[0, 0], m[1, 1] = f / aspect, f
    m[2, 2], m[2, 3] = (far + near) / (near - far), 2.0 * far * near / (near - far)
    m[3, 2] = -1.0
    return m


def _look_at(eye: np.ndarray, target: np.ndarray, up: np.ndarray) -> np.ndarray:
    f = target - eye
    f = f / np.linalg.norm(f)
    s = np.cross(f, up)
    s = s / np.linalg.norm(s)
    u = np.cross(s, f)
    m = np.eye(4, dtype=np.float32)
    m[0, :3], m[1, :3], m[2, :3] = s, u, -f
    m[:3, 3] = -m[:3, :3] @ eye
    return m


class GLViewport(QOpenGLWidget):
    modeChanged = Signal()

    FOV = 32.0

    def __init__(self, parent=None, force_software: bool = False):
        super().__init__(parent)
        fmt = QSurfaceFormat()
        fmt.setDepthBufferSize(24)
        fmt.setSamples(4)
        self.setFormat(fmt)
        self.setMinimumSize(360, 300)

        self.fallback = force_software or gl is None
        self.gl_error = "" if not self.fallback else "OpenGL disabled"
        self._gl_ready = False
        self._prog = self._vao = self._vbo = self._ebo = self._tex = None
        self._pending = None
        self._pending_tex = None
        self._has_tex = False
        self._index_count = 0
        self._size = (100.0, 100.0, 5.0)
        self._fallback_img: Optional[QImage] = None

        self.yaw, self.pitch, self.dist = 0.0, 90.0, 200.0     # degrees; top-down by default
        self.target = np.array([50.0, 50.0, 2.0])
        self.mode = "shaded"           # shaded | normal | texture
        self.wire = False
        self.caption = ""
        self.busy_text = ""
        self.has_mesh = False
        self._last = QPointF()

        self.overlay = ViewOverlay(self)
        QTimer.singleShot(1500, self._check_context)

    # ------------------------------------------------------------- public API
    def set_mesh(self, mesh, z_mm: Optional[np.ndarray] = None, fit: bool = False) -> None:
        sx, sy, sz = mesh.size_mm
        first = not self.has_mesh
        self._size = (sx, sy, sz)
        self.has_mesh = True
        if self.fallback and z_mm is not None:
            ny, nx = z_mm.shape
            hs = hillshade(z_mm, sx / max(nx - 1, 1), sy / max(ny - 1, 1), z_exaggeration=3.0)
            self._fallback_img = array_to_qimage(hs)
        else:
            self._pending = (np.ascontiguousarray(mesh.vertices, dtype=np.float32),
                             np.ascontiguousarray(mesh.faces, dtype=np.uint32))
        if fit or first:
            self.fit_view()
        self.update()

    def set_texture(self, rgb: Optional[np.ndarray]) -> None:
        if rgb is None:
            return
        import cv2
        h, w = rgb.shape[:2]
        s = min(1.0, 2048.0 / max(h, w))
        if s < 1.0:
            rgb = cv2.resize(rgb, (max(1, int(w * s)), max(1, int(h * s))), interpolation=cv2.INTER_AREA)
        self._pending_tex = np.ascontiguousarray((np.clip(rgb, 0, 1) * 255 + 0.5).astype(np.uint8))
        self.update()

    def clear_mesh(self) -> None:
        self.has_mesh = False
        self._pending = None
        self._index_count = 0
        self._fallback_img = None
        self.update()

    def set_mode(self, mode: str) -> None:
        self.mode = mode
        self.update()
        self.modeChanged.emit()

    def set_wire(self, on: bool) -> None:
        self.wire = on
        self.update()

    def set_caption(self, text: str) -> None:
        self.caption = text
        self.overlay.update()

    def set_busy(self, text: str) -> None:
        self.busy_text = text
        self.overlay.update()

    def fit_view(self, keep_angles: bool = False) -> None:
        sx, sy, sz = self._size
        self.target = np.array([sx / 2.0, sy / 2.0, sz / 2.0])
        aspect = max(self.width(), 1) / max(self.height(), 1)
        t = 2.0 * math.tan(math.radians(self.FOV) / 2.0)
        self.dist = max(sy * 1.12 / t, sx * 1.12 / (t * aspect), 1.0)
        if not keep_angles:
            self.yaw, self.pitch = 0.0, 90.0
        self.update()

    def reset_view(self) -> None:
        self.fit_view(keep_angles=False)

    def rotate_x(self, deg: float) -> None:
        self.pitch = float(np.clip(self.pitch + deg, -90.0, 90.0))
        self.update()

    def rotate_z(self, deg: float) -> None:
        self.yaw = (self.yaw + deg) % 360.0
        self.update()

    def view_matrix(self) -> np.ndarray:
        cp, sp = math.cos(math.radians(self.pitch)), math.sin(math.radians(self.pitch))
        cy, sy = math.cos(math.radians(self.yaw)), math.sin(math.radians(self.yaw))
        d = np.array([cp * sy, -cp * cy, sp])
        up = np.array([-sp * sy, sp * cy, cp])
        return _look_at(self.target + d * self.dist, self.target, up)

    def update(self, *args):                       # keep the overlay (axis gizmo) in sync
        super().update(*args)
        if hasattr(self, "overlay"):
            self.overlay.update()

    # ---------------------------------------------------------------- OpenGL
    def _check_context(self) -> None:
        if not self.fallback and (not self.isValid() or not self._gl_ready):
            self._fail("Could not create an OpenGL context")

    def _fail(self, msg: str) -> None:
        self.fallback = True
        self.gl_error = msg
        self.overlay.update()

    def initializeGL(self) -> None:
        if self.fallback:
            return
        try:
            def shader(kind, src):
                s = gl.glCreateShader(kind)
                gl.glShaderSource(s, src)
                gl.glCompileShader(s)
                if not gl.glGetShaderiv(s, gl.GL_COMPILE_STATUS):
                    raise RuntimeError(gl.glGetShaderInfoLog(s).decode(errors="replace"))
                return s

            prog = gl.glCreateProgram()
            gl.glAttachShader(prog, shader(gl.GL_VERTEX_SHADER, VERT))
            gl.glAttachShader(prog, shader(gl.GL_FRAGMENT_SHADER, FRAG))
            gl.glLinkProgram(prog)
            if not gl.glGetProgramiv(prog, gl.GL_LINK_STATUS):
                raise RuntimeError(gl.glGetProgramInfoLog(prog).decode(errors="replace"))
            self._prog = prog
            self._loc = {n: gl.glGetUniformLocation(prog, n) for n in ("uMVP", "uMV", "uMode", "uTex", "uSize", "uLight")}
            self._loc_pos = gl.glGetAttribLocation(prog, "aPos")
            self._vao = gl.glGenVertexArrays(1)
            self._vbo, self._ebo = gl.glGenBuffers(2)
            self._tex = gl.glGenTextures(1)
            gl.glBindTexture(gl.GL_TEXTURE_2D, self._tex)
            white = np.full((1, 1, 3), 255, np.uint8)
            gl.glTexImage2D(gl.GL_TEXTURE_2D, 0, gl.GL_RGB8, 1, 1, 0, gl.GL_RGB, gl.GL_UNSIGNED_BYTE, white)
            self._gl_ready = True
        except Exception as e:
            self._fail(f"OpenGL setup failed: {e}")

    def _upload(self) -> None:
        verts, faces = self._pending
        self._pending = None
        gl.glBindVertexArray(self._vao)
        gl.glBindBuffer(gl.GL_ARRAY_BUFFER, self._vbo)
        gl.glBufferData(gl.GL_ARRAY_BUFFER, verts.nbytes, verts, gl.GL_STATIC_DRAW)
        gl.glEnableVertexAttribArray(self._loc_pos)
        gl.glVertexAttribPointer(self._loc_pos, 3, gl.GL_FLOAT, gl.GL_FALSE, 0, None)
        gl.glBindBuffer(gl.GL_ELEMENT_ARRAY_BUFFER, self._ebo)
        gl.glBufferData(gl.GL_ELEMENT_ARRAY_BUFFER, faces.nbytes, faces, gl.GL_STATIC_DRAW)
        self._index_count = int(faces.size)
        gl.glBindVertexArray(0)

    def _upload_texture(self) -> None:
        img = self._pending_tex
        self._pending_tex = None
        h, w = img.shape[:2]
        gl.glPixelStorei(gl.GL_UNPACK_ALIGNMENT, 1)
        gl.glBindTexture(gl.GL_TEXTURE_2D, self._tex)
        gl.glTexImage2D(gl.GL_TEXTURE_2D, 0, gl.GL_RGB8, w, h, 0, gl.GL_RGB, gl.GL_UNSIGNED_BYTE, img)
        gl.glGenerateMipmap(gl.GL_TEXTURE_2D)
        gl.glTexParameteri(gl.GL_TEXTURE_2D, gl.GL_TEXTURE_MIN_FILTER, gl.GL_LINEAR_MIPMAP_LINEAR)
        gl.glTexParameteri(gl.GL_TEXTURE_2D, gl.GL_TEXTURE_MAG_FILTER, gl.GL_LINEAR)
        gl.glTexParameteri(gl.GL_TEXTURE_2D, gl.GL_TEXTURE_WRAP_S, gl.GL_CLAMP_TO_EDGE)
        gl.glTexParameteri(gl.GL_TEXTURE_2D, gl.GL_TEXTURE_WRAP_T, gl.GL_CLAMP_TO_EDGE)
        self._has_tex = True

    def paintGL(self) -> None:
        if self.fallback or not self._gl_ready:
            return
        try:
            self._paint()
        except Exception as e:
            self._fail(f"OpenGL error: {e}")

    def _paint(self) -> None:
        dpr = self.devicePixelRatioF()
        w, h = max(1, int(self.width() * dpr)), max(1, int(self.height() * dpr))
        gl.glViewport(0, 0, w, h)
        gl.glClearColor(*theme.VIEWPORT_BG, 1.0)
        gl.glClear(gl.GL_COLOR_BUFFER_BIT | gl.GL_DEPTH_BUFFER_BIT)
        if self._pending is not None:
            self._upload()
        if self._pending_tex is not None:
            self._upload_texture()
        if not self.has_mesh or self._index_count == 0:
            return

        view = self.view_matrix()
        sx, sy, sz = self._size
        far = self.dist + 4.0 * max(sx, sy, 1.0)
        proj = _perspective(self.FOV, w / h, max(self.dist * 0.02, 0.05), far)
        mvp = proj @ view

        gl.glEnable(gl.GL_DEPTH_TEST)
        gl.glUseProgram(self._prog)
        gl.glUniformMatrix4fv(self._loc["uMVP"], 1, gl.GL_TRUE, np.ascontiguousarray(mvp, np.float32))
        gl.glUniformMatrix4fv(self._loc["uMV"], 1, gl.GL_TRUE, np.ascontiguousarray(view, np.float32))
        gl.glUniform2f(self._loc["uSize"], float(sx), float(sy))
        gl.glUniform3f(self._loc["uLight"], -0.45, 0.55, 0.70)
        gl.glActiveTexture(gl.GL_TEXTURE0)
        gl.glBindTexture(gl.GL_TEXTURE_2D, self._tex)
        gl.glUniform1i(self._loc["uTex"], 0)
        mode = {"shaded": 0, "normal": 1, "texture": 2 if self._has_tex else 0}[self.mode]
        gl.glUniform1i(self._loc["uMode"], mode)

        gl.glBindVertexArray(self._vao)
        if self.wire:
            gl.glEnable(gl.GL_POLYGON_OFFSET_FILL)
            gl.glPolygonOffset(1.0, 1.0)
        gl.glDrawElements(gl.GL_TRIANGLES, self._index_count, gl.GL_UNSIGNED_INT, None)
        if self.wire:
            gl.glDisable(gl.GL_POLYGON_OFFSET_FILL)
            gl.glUniform1i(self._loc["uMode"], 3)
            gl.glEnable(gl.GL_BLEND)
            gl.glBlendFunc(gl.GL_SRC_ALPHA, gl.GL_ONE_MINUS_SRC_ALPHA)
            gl.glDepthMask(gl.GL_FALSE)
            gl.glPolygonMode(gl.GL_FRONT_AND_BACK, gl.GL_LINE)
            gl.glDrawElements(gl.GL_TRIANGLES, self._index_count, gl.GL_UNSIGNED_INT, None)
            gl.glPolygonMode(gl.GL_FRONT_AND_BACK, gl.GL_FILL)
            gl.glDepthMask(gl.GL_TRUE)
            gl.glDisable(gl.GL_BLEND)
        gl.glBindVertexArray(0)
        gl.glUseProgram(0)

    # ----------------------------------------------------------------- mouse
    def resizeEvent(self, e):
        super().resizeEvent(e)
        self.overlay.setGeometry(self.rect())

    def mousePressEvent(self, e):
        self._last = e.position()

    def mouseDoubleClickEvent(self, e):
        self.reset_view()

    def mouseMoveEvent(self, e):
        if self.fallback:
            return
        p = e.position()
        dx, dy = p.x() - self._last.x(), p.y() - self._last.y()
        self._last = p
        if e.buttons() & Qt.LeftButton:
            self.yaw = (self.yaw - dx * 0.4) % 360.0
            self.pitch = float(np.clip(self.pitch + dy * 0.4, -90.0, 90.0))
        elif e.buttons() & (Qt.RightButton | Qt.MiddleButton):
            view = self.view_matrix()
            right, up = view[0, :3].astype(float), view[1, :3].astype(float)
            k = 2.0 * self.dist * math.tan(math.radians(self.FOV) / 2.0) / max(self.height(), 1)
            self.target = self.target - right * dx * k + up * dy * k
        else:
            return
        self.update()

    def wheelEvent(self, e):
        if self.fallback:
            return
        size = max(self._size[0], self._size[1], 1.0)
        self.dist = float(np.clip(self.dist * (0.9 ** (e.angleDelta().y() / 120.0)), size * 0.03, size * 25.0))
        self.update()


class ViewOverlay(QWidget):
    """Transparent layer on top of the GL view: axis gizmo, captions, fallback picture."""

    def __init__(self, vp: GLViewport):
        super().__init__(vp)
        self.vp = vp
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WA_NoSystemBackground)
        self.setAttribute(Qt.WA_TranslucentBackground)

    def paintEvent(self, _):
        vp = self.vp
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()

        if vp.fallback:
            p.fillRect(self.rect(), QColor(*[int(c * 255) for c in theme.VIEWPORT_BG]))
            if vp._fallback_img is not None:
                box = QRectF(16, 40, w - 32, h - 80)
                img = vp._fallback_img
                s = min(box.width() / img.width(), box.height() / img.height())
                tw, th = img.width() * s, img.height() * s
                p.drawImage(QRectF(box.center().x() - tw / 2, box.center().y() - th / 2, tw, th), img)
            p.setPen(QColor(theme.MUTED))
            p.setFont(QFont(self.font().family(), 9))
            p.drawText(QRectF(16, 10, w - 32, 24), Qt.AlignLeft | Qt.AlignVCenter,
                       "3D view unavailable on this PC, showing a shaded preview" +
                       (f"  ({vp.gl_error[:70]})" if vp.gl_error else ""))

        if not vp.has_mesh:
            p.setPen(QColor(theme.MUTED))
            f = QFont(self.font().family(), 12)
            p.setFont(f)
            p.drawText(self.rect(), Qt.AlignCenter, "Open an image to see the relief here")

        # axis gizmo
        if vp.has_mesh and not vp.fallback:
            R = vp.view_matrix()[:3, :3]
            c = QPointF(52, h - 52)
            axes = [("X", (1, 0, 0), "#e5584f"), ("Y", (0, 1, 0), "#46c08f"), ("Z", (0, 0, 1), "#5b9bff")]
            items = sorted(((R @ np.array(v, float), n, col) for n, v, col in axes), key=lambda t: t[0][2])
            for v, n, col in items:
                end = QPointF(c.x() + v[0] * 30, c.y() - v[1] * 30)
                p.setPen(QPen(QColor(col), 2.2))
                p.drawLine(c, end)
                p.setPen(QColor(col))
                p.setFont(QFont(self.font().family(), 9, QFont.Bold))
                p.drawText(QRectF(end.x() - 8 + v[0] * 8, end.y() - 8 - v[1] * 8, 16, 16), Qt.AlignCenter, n)

        # caption and hints
        p.setFont(QFont(self.font().family(), 9))
        if vp.caption:
            p.setPen(QColor(theme.MUTED))
            p.drawText(QRectF(14, 8, w - 28, 20), Qt.AlignLeft | Qt.AlignVCenter, vp.caption) if not vp.fallback else None
        if vp.has_mesh and not vp.fallback:
            p.setPen(QColor("#5d6b80"))
            p.drawText(QRectF(14, h - 26, w - 28, 18), Qt.AlignRight | Qt.AlignVCenter,
                       "Left-drag rotates, right-drag pans, scroll zooms, double-click resets")
        if vp.busy_text:
            txt = vp.busy_text
            fm = p.fontMetrics()
            tw = fm.horizontalAdvance(txt) + 24
            r = QRectF(w - tw - 14, 8, tw, 24)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(20, 27, 36, 230))
            p.drawRoundedRect(r, 12, 12)
            p.setPen(QColor(theme.ACCENT))
            p.drawText(r, Qt.AlignCenter, txt)
        p.end()
