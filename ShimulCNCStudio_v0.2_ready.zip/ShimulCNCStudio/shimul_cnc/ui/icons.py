"""Small vector icons drawn at runtime (no image files needed)."""
from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QIcon, QPainter, QPen, QPixmap, QPolygonF

from . import theme


def _pix(kind: str, color: str, size: int = 26) -> QPixmap:
    pm = QPixmap(size * 2, size * 2)
    pm.setDevicePixelRatio(2.0)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    pen = QPen(QColor(color), 1.7)
    pen.setCapStyle(Qt.RoundCap)
    pen.setJoinStyle(Qt.RoundJoin)
    p.setPen(pen)
    s = float(size)
    if kind == "design":            # picture frame with a hill and a sun
        p.drawRoundedRect(QRectF(3, 4, s - 6, s - 8), 3, 3)
        p.drawPolyline(QPolygonF([QPointF(5, s - 8), QPointF(10, 12), QPointF(14, 17), QPointF(17, 14), QPointF(s - 5, s - 8)]))
        p.drawEllipse(QRectF(s - 11, 7, 4, 4))
    elif kind == "crop":            # crop marks
        p.drawPolyline(QPolygonF([QPointF(8, 3), QPointF(8, s - 8), QPointF(s - 3, s - 8)]))
        p.drawPolyline(QPolygonF([QPointF(3, 8), QPointF(s - 8, 8), QPointF(s - 8, s - 3)]))
    else:                           # mesh: an isometric slab with grid lines
        top = QPolygonF([QPointF(s / 2, 3), QPointF(s - 3, 9), QPointF(s / 2, 15), QPointF(3, 9)])
        p.drawPolygon(top)
        p.drawPolyline(QPolygonF([QPointF(3, 9), QPointF(3, 15), QPointF(s / 2, 21), QPointF(s - 3, 15), QPointF(s - 3, 9)]))
        p.drawLine(QPointF(s / 2, 15), QPointF(s / 2, 21))
        p.drawLine(QPointF(s * 0.28, 6), QPointF(s * 0.72, 12))
        p.drawLine(QPointF(s * 0.72, 6), QPointF(s * 0.28, 12))
    p.end()
    return pm


def nav_icon(kind: str) -> QIcon:
    icon = QIcon()
    icon.addPixmap(_pix(kind, theme.MUTED), QIcon.Normal, QIcon.Off)
    icon.addPixmap(_pix(kind, theme.ACCENT), QIcon.Normal, QIcon.On)
    return icon
