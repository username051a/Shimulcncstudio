"""Dark workshop theme: ink background, one amber (cutter) accent."""
import tempfile
from pathlib import Path

from PySide6.QtCore import QPointF, Qt
from PySide6.QtGui import QColor, QFont, QPainter, QPalette, QPen, QPixmap, QPolygonF
from PySide6.QtWidgets import QApplication

BG = "#0c1016"
BG_DEEP = "#0a0d12"
PANEL = "#121820"
FIELD = "#0e141b"
BORDER = "#1f2935"
BORDER_HI = "#2a3647"
TEXT = "#dbe2ec"
MUTED = "#8794a8"
ACCENT = "#f0a830"
ACCENT_HI = "#f6b94d"
OK = "#46c08f"
DANGER = "#e5584f"
VIEWPORT_BG = (0.043, 0.055, 0.075)

QSS = f"""
QWidget {{ background: {BG}; color: {TEXT}; font-family: "Segoe UI", "Inter", "DejaVu Sans"; font-size: 12px; }}
QLabel {{ background: transparent; }}
QMainWindow, #root {{ background: {BG}; }}
#sidebar {{ background: {BG_DEEP}; border-right: 1px solid #1b2430; }}
#brand {{ color: {TEXT}; font-size: 15px; font-weight: 600; background: transparent; }}
#badge {{ color: {ACCENT}; border: 1px solid #5a4318; border-radius: 10px; padding: 2px 10px; background: #1c150a; }}
#topbar {{ background: {BG}; border-bottom: 1px solid #1b2430; }}
#sideBtn {{ background: transparent; border: none; border-left: 3px solid transparent; border-radius: 0;
            padding: 14px 4px; color: {MUTED}; font-size: 11px; }}
#sideBtn:hover {{ color: {TEXT}; background: #101620; }}
#sideBtn:checked {{ color: {ACCENT}; border-left: 3px solid {ACCENT}; background: #131a24; }}
#panel {{ background: {PANEL}; border: 1px solid {BORDER}; border-radius: 8px; }}
#sectionTitle {{ color: #a9b8cc; font-weight: 600; font-size: 12px; background: transparent; }}
#muted {{ color: {MUTED}; background: transparent; }}
#hint {{ color: {MUTED}; font-size: 11px; background: transparent; }}
#statValue {{ color: {TEXT}; font-weight: 600; background: transparent; }}
#thumb {{ background: {FIELD}; border: 1px solid {BORDER}; border-radius: 6px; color: {MUTED}; }}
QPushButton {{ background: #19222d; border: 1px solid {BORDER_HI}; border-radius: 6px; padding: 6px 12px; color: {TEXT}; }}
QPushButton:hover {{ background: #202c3a; border-color: #3b4b61; }}
QPushButton:pressed {{ background: #141c26; }}
QPushButton:disabled {{ color: #566376; background: {PANEL}; border-color: {BORDER}; }}
QPushButton[primary="true"] {{ background: {ACCENT}; color: #1a1305; border: 1px solid {ACCENT}; font-weight: 600; padding: 8px 14px; }}
QPushButton[primary="true"]:hover {{ background: {ACCENT_HI}; border-color: {ACCENT_HI}; }}
QPushButton[primary="true"]:pressed {{ background: #d99220; }}
QPushButton[primary="true"]:disabled {{ background: #4a3c1c; color: #8a7a52; border-color: #4a3c1c; }}
QPushButton[chip="true"] {{ padding: 3px 9px; border-radius: 11px; background: #141b24; font-size: 11px; min-width: 0; }}
QPushButton[chip="true"]:checked {{ background: #2a2110; border-color: {ACCENT}; color: {ACCENT}; }}
QPushButton[toggle="true"]:checked {{ background: #2a2110; border-color: {ACCENT}; color: {ACCENT}; }}
QSlider::groove:horizontal {{ height: 4px; background: #233042; border-radius: 2px; }}
QSlider::sub-page:horizontal {{ background: {ACCENT}; border-radius: 2px; }}
QSlider::handle:horizontal {{ background: #f4f7fb; width: 12px; height: 12px; margin: -5px 0; border-radius: 6px; }}
QSlider::handle:horizontal:hover {{ background: #ffffff; }}
QDoubleSpinBox, QSpinBox, QComboBox {{ background: {FIELD}; border: 1px solid {BORDER_HI}; border-radius: 6px;
            padding: 4px 8px; min-height: 20px; selection-background-color: {ACCENT}; selection-color: #1a1305; }}
QDoubleSpinBox:focus, QSpinBox:focus, QComboBox:focus {{ border-color: {ACCENT}; }}
QDoubleSpinBox::up-button, QDoubleSpinBox::down-button, QSpinBox::up-button, QSpinBox::down-button {{ width: 16px; border: none; background: transparent; }}
QComboBox::drop-down {{ border: none; width: 22px; }}
QComboBox QAbstractItemView {{ background: {PANEL}; border: 1px solid {BORDER_HI};
            selection-background-color: #2a2110; selection-color: {ACCENT}; outline: 0; }}
QCheckBox, QRadioButton {{ spacing: 8px; background: transparent; }}
QCheckBox::indicator {{ width: 15px; height: 15px; border: 1px solid #3a4a60; border-radius: 4px; background: {FIELD}; }}
QCheckBox::indicator:checked {{ background: {ACCENT}; border-color: {ACCENT}; }}
QRadioButton::indicator {{ width: 15px; height: 15px; border: 1px solid #3a4a60; border-radius: 8px; background: {FIELD}; }}
QRadioButton::indicator:checked {{ background: {ACCENT}; border: 4px solid {FIELD}; outline: 1px solid {ACCENT}; }}
QScrollArea {{ border: none; background: transparent; }}
QScrollBar:vertical {{ width: 8px; background: transparent; margin: 0; }}
QScrollBar::handle:vertical {{ background: {BORDER_HI}; border-radius: 4px; min-height: 30px; }}
QScrollBar::handle:vertical:hover {{ background: #3b4b61; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical, QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{ height: 0; background: transparent; }}
QProgressBar {{ background: {FIELD}; border: none; border-radius: 3px; max-height: 6px; min-height: 6px; text-align: center; color: transparent; }}
QProgressBar::chunk {{ background: {ACCENT}; border-radius: 3px; }}
QToolTip {{ background: #19222d; color: {TEXT}; border: 1px solid {BORDER_HI}; padding: 4px; }}
QMenuBar {{ background: {BG_DEEP}; border-bottom: 1px solid #1b2430; }}
QMenuBar::item {{ padding: 5px 10px; background: transparent; }}
QMenuBar::item:selected {{ background: #1a2330; }}
QMenu {{ background: {PANEL}; border: 1px solid {BORDER_HI}; padding: 4px; }}
QMenu::item {{ padding: 6px 22px; border-radius: 4px; }}
QMenu::item:selected {{ background: #2a2110; color: {ACCENT}; }}
QStatusBar {{ background: {BG_DEEP}; border-top: 1px solid #1b2430; color: {MUTED}; }}
QStatusBar::item {{ border: none; }}
QMessageBox {{ background: {PANEL}; }}
"""


def _tick_image() -> str:
    """Draws a check mark once and returns its path for the stylesheet."""
    path = Path(tempfile.gettempdir()) / "shimul_cnc_tick.png"
    pm = QPixmap(30, 30)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    pen = QPen(QColor("#1a1305"), 3.6)
    pen.setCapStyle(Qt.RoundCap)
    pen.setJoinStyle(Qt.RoundJoin)
    p.setPen(pen)
    p.drawPolyline(QPolygonF([QPointF(7, 16), QPointF(13, 22), QPointF(23, 9)]))
    p.end()
    pm.save(str(path))
    return path.as_posix()


def apply_theme(app: QApplication) -> None:
    app.setStyle("Fusion")
    pal = QPalette()
    pal.setColor(QPalette.Window, QColor(BG))
    pal.setColor(QPalette.WindowText, QColor(TEXT))
    pal.setColor(QPalette.Base, QColor(FIELD))
    pal.setColor(QPalette.AlternateBase, QColor(PANEL))
    pal.setColor(QPalette.Text, QColor(TEXT))
    pal.setColor(QPalette.Button, QColor("#19222d"))
    pal.setColor(QPalette.ButtonText, QColor(TEXT))
    pal.setColor(QPalette.Highlight, QColor(ACCENT))
    pal.setColor(QPalette.HighlightedText, QColor("#1a1305"))
    pal.setColor(QPalette.ToolTipBase, QColor("#19222d"))
    pal.setColor(QPalette.ToolTipText, QColor(TEXT))
    pal.setColor(QPalette.PlaceholderText, QColor(MUTED))
    app.setPalette(pal)
    f = app.font()
    f.setPointSize(9)
    app.setFont(f)
    extra = f"""
QCheckBox::indicator:checked {{ background: {ACCENT}; border-color: {ACCENT}; image: url({_tick_image()}); }}
QRadioButton::indicator:checked {{ border: 1px solid {ACCENT};
    background: qradialgradient(cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5,
                                stop:0 {ACCENT}, stop:0.5 {ACCENT}, stop:0.56 {FIELD}, stop:1 {FIELD}); }}
"""
    app.setStyleSheet(QSS + extra)
