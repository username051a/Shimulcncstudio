"""Reusable widgets: slider rows, spin rows, sections, image thumbnails."""
from __future__ import annotations

from typing import Optional

import numpy as np
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QImage, QPixmap
from PySide6.QtWidgets import (QDoubleSpinBox, QFrame, QHBoxLayout, QLabel, QSizePolicy, QSlider,
                               QVBoxLayout, QWidget)


def to_u8(a: np.ndarray) -> np.ndarray:
    if a.dtype == np.uint8:
        return a
    return (np.clip(a, 0.0, 1.0) * 255.0 + 0.5).astype(np.uint8)


def array_to_qimage(a: np.ndarray) -> QImage:
    """uint8/float array (H,W) or (H,W,3) -> QImage that owns its memory."""
    a = np.ascontiguousarray(to_u8(a))
    h, w = a.shape[:2]
    fmt = QImage.Format_Grayscale8 if a.ndim == 2 else QImage.Format_RGB888
    return QImage(a.data, w, h, a.strides[0], fmt).copy()


def button(text: str, primary: bool = False, chip: bool = False, toggle: bool = False, tip: str = ""):
    from PySide6.QtWidgets import QPushButton
    b = QPushButton(text)
    b.setCursor(Qt.PointingHandCursor)
    if primary:
        b.setProperty("primary", True)
    if chip:
        b.setProperty("chip", True)
        b.setCheckable(True) if toggle else None
    elif toggle:
        b.setProperty("toggle", True)
        b.setCheckable(True)
    if tip:
        b.setToolTip(tip)
    return b


class Section(QFrame):
    """A titled panel."""

    def __init__(self, title: str, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setObjectName("panel")
        outer = QVBoxLayout(self)
        outer.setContentsMargins(12, 10, 12, 12)
        outer.setSpacing(8)
        t = QLabel(title)
        t.setObjectName("sectionTitle")
        outer.addWidget(t)
        self.body = QVBoxLayout()
        self.body.setSpacing(6)
        outer.addLayout(self.body)

    def add(self, w) -> None:
        self.body.addWidget(w)

    def add_layout(self, lay) -> None:
        self.body.addLayout(lay)


class ParamSlider(QWidget):
    """label | slider | value. Double-click the row to reset to the default."""

    valueChanged = Signal(float)

    def __init__(self, label: str, lo: float, hi: float, value: float, step: float = 1.0,
                 decimals: int = 0, tip: str = ""):
        super().__init__()
        self._lo, self._hi, self._step, self._dec, self._default = lo, hi, step, decimals, value
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 1, 0, 1)
        lay.setSpacing(8)
        self.label = QLabel(label)
        self.label.setFixedWidth(112)
        self.slider = QSlider(Qt.Horizontal)
        self.slider.setRange(0, int(round((hi - lo) / step)))
        self.val = QLabel()
        self.val.setFixedWidth(42)
        self.val.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.val.setObjectName("statValue")
        lay.addWidget(self.label)
        lay.addWidget(self.slider, 1)
        lay.addWidget(self.val)
        if tip:
            self.setToolTip(tip + "\n(double-click to reset)")
        else:
            self.setToolTip("Double-click to reset")
        self.setValue(value)
        self.slider.valueChanged.connect(self._changed)

    def value(self) -> float:
        return self._lo + self.slider.value() * self._step

    def setValue(self, v: float) -> None:
        self.slider.blockSignals(True)
        self.slider.setValue(int(round((v - self._lo) / self._step)))
        self.slider.blockSignals(False)
        self._show()

    def _show(self) -> None:
        self.val.setText(f"{self.value():.{self._dec}f}")

    def _changed(self, _):
        self._show()
        self.valueChanged.emit(self.value())

    def mouseDoubleClickEvent(self, e):
        self.setValue(self._default)
        self.valueChanged.emit(self._default)


class SpinRow(QWidget):
    valueChanged = Signal(float)

    def __init__(self, label: str, lo: float, hi: float, value: float, step: float = 0.5,
                 decimals: int = 2, suffix: str = " mm", tip: str = ""):
        super().__init__()
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 1, 0, 1)
        lay.setSpacing(8)
        self.label = QLabel(label)
        self.label.setFixedWidth(112)
        self.spin = QDoubleSpinBox()
        self.spin.setRange(lo, hi)
        self.spin.setDecimals(decimals)
        self.spin.setSingleStep(step)
        self.spin.setSuffix(suffix)
        self.spin.setValue(value)
        self.spin.setKeyboardTracking(False)
        self.spin.setAlignment(Qt.AlignRight)
        lay.addWidget(self.label)
        lay.addWidget(self.spin, 1)
        if tip:
            self.setToolTip(tip)
        self.spin.valueChanged.connect(self.valueChanged)

    def value(self) -> float:
        return self.spin.value()

    def setValue(self, v: float) -> None:
        self.spin.blockSignals(True)
        self.spin.setValue(v)
        self.spin.blockSignals(False)


class ImageThumb(QLabel):
    """Keeps the picture's aspect ratio inside the available box."""

    def __init__(self, placeholder: str = "No image", min_height: int = 120):
        super().__init__(placeholder)
        self.setObjectName("thumb")
        self.setAlignment(Qt.AlignCenter)
        self.setMinimumHeight(min_height)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self._img: Optional[QImage] = None
        self._placeholder = placeholder

    def set_array(self, arr: Optional[np.ndarray]) -> None:
        if arr is None:
            self._img = None
            self.setPixmap(QPixmap())
            self.setText(self._placeholder)
            return
        self._img = array_to_qimage(arr)
        self._refresh()

    def _refresh(self) -> None:
        if self._img is None:
            return
        self.setText("")
        self.setPixmap(QPixmap.fromImage(self._img).scaled(
            self.contentsRect().size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._refresh()
