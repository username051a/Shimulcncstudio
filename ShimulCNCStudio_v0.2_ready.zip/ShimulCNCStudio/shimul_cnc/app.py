"""Program entry point."""
from __future__ import annotations

import argparse
import logging
import os
import sys
import traceback
from logging.handlers import RotatingFileHandler
from pathlib import Path


def _log_dir() -> Path:
    base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), ".local", "share")
    d = Path(base) / "ShimulCNCStudio"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _setup_logging() -> Path:
    path = _log_dir() / "app.log"
    handler = RotatingFileHandler(path, maxBytes=500_000, backupCount=2, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
    logging.getLogger().addHandler(handler)
    logging.getLogger().setLevel(logging.INFO)
    return path


def selftest(out_path: str) -> int:
    """Checks that every part of the program works (used to verify the built .exe)."""
    os.environ["QT_QPA_PLATFORM"] = "offscreen"
    lines, ok = [], True

    def step(name, fn):
        nonlocal ok
        try:
            lines.append(f"OK   {name}: {fn()}")
        except BaseException as e:      # noqa: BLE001 - report everything
            ok = False
            lines.append(f"FAIL {name}: {e!r}")

    def libs():
        import cv2, numpy, PIL
        return f"numpy {numpy.__version__}, opencv {cv2.__version__}, pillow {PIL.__version__}"

    def ort_info():
        import onnxruntime as ort
        return f"{ort.__version__} providers={ort.get_available_providers()}"

    def opengl():
        from OpenGL import GL  # noqa: F401
        from PySide6.QtOpenGLWidgets import QOpenGLWidget  # noqa: F401
        return "PyOpenGL and QtOpenGLWidgets import fine"

    def engine():
        import tempfile

        import numpy as np

        from .core import ReliefParams, generate_relief, write_binary_stl
        img = (np.random.default_rng(1).random((160, 120, 3))).astype("float32")
        r = generate_relief(img, ReliefParams(mesh_level=5, use_mask=False))
        with tempfile.TemporaryDirectory() as d:
            n = write_binary_stl(Path(d) / "t.stl", r.mesh)
        return f"{r.mesh.n_faces} faces, STL {n} bytes"

    def ui():
        from PySide6.QtWidgets import QApplication

        from .ui.main_window import MainWindow
        from .ui.state import AppState
        from .ui.theme import apply_theme
        app = QApplication.instance() or QApplication(sys.argv[:1])
        apply_theme(app)
        w = MainWindow(AppState(), force_software=True)
        w.show()
        app.processEvents()
        w.close()
        return "main window created"

    def model():
        from .ai import find_model
        return str(find_model())

    from . import __version__
    step("version", lambda: __version__ + (" (frozen build)" if getattr(sys, "frozen", False) else " (source)"))
    for name, fn in (("libraries", libs), ("onnxruntime", ort_info), ("opengl", opengl),
                     ("engine", engine), ("ui", ui), ("ai model file", model)):
        step(name, fn)
    lines.append("RESULT: " + ("ALL OK" if ok else "FAILED"))
    Path(out_path).write_text("\n".join(lines) + "\n", encoding="utf-8")
    return 0 if ok else 1


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="ShimulCNCStudio")
    ap.add_argument("image", nargs="?", help="image to open at start")
    ap.add_argument("--software-viewport", action="store_true", help="skip OpenGL, use the 2D shaded preview")
    ap.add_argument("--selftest", metavar="FILE", help="run built-in checks, write the report to FILE and exit")
    args = ap.parse_args(argv)
    if args.selftest:
        return selftest(args.selftest)

    log_path = _setup_logging()

    from PySide6.QtCore import Qt
    from PySide6.QtGui import QIcon
    from PySide6.QtWidgets import QApplication, QMessageBox

    try:
        QApplication.setAttribute(Qt.AA_UseDesktopOpenGL, True)
        QApplication.setAttribute(Qt.AA_ShareOpenGLContexts, True)
    except Exception:
        pass
    app = QApplication(sys.argv[:1])
    app.setApplicationName("Shimul CNC Studio")
    app.setOrganizationName("ShimulCNC")

    from . import APP_NAME
    from .ai.model_manager import app_root
    from .ui.main_window import MainWindow
    from .ui.state import AppState
    from .ui.theme import apply_theme

    apply_theme(app)
    icon = app_root() / "assets" / "icon.png"
    if icon.exists():
        app.setWindowIcon(QIcon(str(icon)))

    def hook(exc_type, exc, tb):
        text = "".join(traceback.format_exception(exc_type, exc, tb))
        logging.error("Unhandled exception:\n%s", text)
        try:
            QMessageBox.critical(None, f"{APP_NAME} - unexpected error",
                                 f"{exc}\n\nDetails were saved to:\n{log_path}")
        except Exception:
            pass

    sys.excepthook = hook

    state = AppState()
    win = MainWindow(state, force_software=args.software_viewport)
    win.show()
    if args.image:
        win.load_path(args.image)
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
