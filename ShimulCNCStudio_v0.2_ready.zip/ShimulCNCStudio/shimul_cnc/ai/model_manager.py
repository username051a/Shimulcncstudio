"""Locate / download / import the free AI depth model (Depth Anything V2 Small, Apache-2.0)."""
from __future__ import annotations

import os
import shutil
import sys
import urllib.request
from pathlib import Path
from typing import Callable, Iterable, List, Optional

MODEL_FILENAME = "depth_anything_v2_small.onnx"
MODEL_URLS = [
    "https://huggingface.co/onnx-community/depth-anything-v2-small/resolve/main/onnx/model.onnx",
    "https://hf-mirror.com/onnx-community/depth-anything-v2-small/resolve/main/onnx/model.onnx",
]
MODEL_APPROX_BYTES = 99_100_000      # fp32 model is ~99.1 MB
MIN_VALID_BYTES = 90_000_000
APP_DIR_NAME = "ShimulCNCStudio"

Progress = Optional[Callable[[float, str], None]]


class ModelError(Exception):
    pass


class DownloadCancelled(Exception):
    pass


def app_root() -> Path:
    """Folder that contains the program (works for source runs and PyInstaller builds)."""
    if getattr(sys, "frozen", False):
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
    return Path(__file__).resolve().parents[2]


def user_models_dir() -> Path:
    base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), ".local", "share")
    return Path(base) / APP_DIR_NAME / "models"


def candidate_paths() -> List[Path]:
    paths = [app_root() / "models" / MODEL_FILENAME]
    if getattr(sys, "frozen", False):
        paths.append(Path(sys.executable).parent / "models" / MODEL_FILENAME)
    paths.append(user_models_dir() / MODEL_FILENAME)
    return paths


def find_model() -> Optional[Path]:
    for p in candidate_paths():
        try:
            if p.is_file() and p.stat().st_size > 5_000_000:
                return p
        except OSError:
            pass
    return None


def download_model(
    progress: Progress = None,
    cancel: Optional[Callable[[], bool]] = None,
    urls: Optional[Iterable[str]] = None,
    min_bytes: int = MIN_VALID_BYTES,
    dest_dir: Optional[Path] = None,
) -> Path:
    """Download the model into the user's models folder. Returns the final path."""
    dest_dir = Path(dest_dir) if dest_dir else user_models_dir()
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / MODEL_FILENAME
    part = dest.with_name(dest.name + ".part")
    last_err: Optional[BaseException] = None

    for url in (list(urls) if urls else MODEL_URLS):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "ShimulCNCStudio/1.0"})
            done = 0
            with urllib.request.urlopen(req, timeout=30) as resp, open(part, "wb") as f:
                total = int(resp.headers.get("Content-Length") or 0) or MODEL_APPROX_BYTES
                while True:
                    if cancel and cancel():
                        raise DownloadCancelled()
                    chunk = resp.read(1 << 20)
                    if not chunk:
                        break
                    f.write(chunk)
                    done += len(chunk)
                    if progress:
                        progress(min(1.0, done / total), f"Downloading AI model  {done / 1e6:.0f} / {total / 1e6:.0f} MB")
            if done < min_bytes:
                raise ModelError(f"Download incomplete ({done / 1e6:.1f} MB).")
            os.replace(part, dest)
            return dest
        except DownloadCancelled:
            _silent_remove(part)
            raise
        except Exception as e:  # try the next mirror
            last_err = e
            _silent_remove(part)
    raise ModelError(f"Could not download the AI model. Check your internet connection. ({last_err})")


def import_model(src: Path) -> Path:
    """Copy a user supplied .onnx depth model into the models folder after a quick validity check."""
    src = Path(src)
    if not src.is_file():
        raise ModelError("File not found.")
    try:
        import onnxruntime as ort
        ort.InferenceSession(str(src), providers=["CPUExecutionProvider"])
    except Exception as e:
        raise ModelError(f"This file is not a valid ONNX model: {e}")
    dest_dir = user_models_dir()
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / MODEL_FILENAME
    shutil.copyfile(src, dest)
    return dest


def _silent_remove(p: Path) -> None:
    try:
        p.unlink()
    except OSError:
        pass
