"""Depth Anything V2 Small running locally through ONNX Runtime (DirectML GPU or CPU).

Free and offline. Output is relative inverse depth: bright = near = high relief.
"""
from __future__ import annotations

import gc
import threading
from pathlib import Path
from typing import Optional, Tuple

import cv2
import numpy as np

from ..core.depth_sources import DepthSource, Progress

MEAN = np.array([0.485, 0.456, 0.406], dtype=np.float32)
STD = np.array([0.229, 0.224, 0.225], dtype=np.float32)
SHORT_SIDE = 518          # model's native size
MAX_LONG_SIDE = 1036      # keeps CPU time and GPU memory sane on long panels
MULTIPLE = 14


def _round_to(v: float, m: int = MULTIPLE) -> int:
    return max(m, int(round(v / m)) * m)


class DepthAnythingOnnx(DepthSource):
    name = "AI Depth (Depth Anything V2 Small)"

    def __init__(self, model_path: Path, use_gpu: bool = True):
        self.model_path = Path(model_path)
        self.use_gpu = use_gpu
        self._session = None
        self._input_name = ""
        self._input_type = "tensor(float)"
        self._fixed_hw: Optional[Tuple[int, int]] = None
        self._lock = threading.Lock()
        self.provider = "not loaded"

    # ---------------------------------------------------------------- session
    @property
    def loaded(self) -> bool:
        return self._session is not None

    @property
    def device_label(self) -> str:
        return {"DmlExecutionProvider": "GPU (DirectML)", "CUDAExecutionProvider": "GPU (CUDA)",
                "CPUExecutionProvider": "CPU"}.get(self.provider, self.provider)

    def load(self, force_cpu: bool = False) -> None:
        if self._session is not None:
            return
        import onnxruntime as ort

        avail = ort.get_available_providers()
        providers = []
        if self.use_gpu and not force_cpu:
            if "DmlExecutionProvider" in avail:
                providers.append("DmlExecutionProvider")
            elif "CUDAExecutionProvider" in avail:
                providers.append("CUDAExecutionProvider")
        providers.append("CPUExecutionProvider")

        def make(provs):
            so = ort.SessionOptions()
            so.log_severity_level = 3
            if "DmlExecutionProvider" in provs:          # required by DirectML
                so.enable_mem_pattern = False
                so.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
            return ort.InferenceSession(str(self.model_path), so, providers=provs)

        try:
            sess = make(providers)
        except Exception:
            if providers == ["CPUExecutionProvider"]:
                raise
            sess = make(["CPUExecutionProvider"])

        inp = sess.get_inputs()[0]
        self._input_name = inp.name
        self._input_type = inp.type
        h, w = (list(inp.shape) + [None] * 4)[2:4]
        self._fixed_hw = (h, w) if isinstance(h, int) and isinstance(w, int) else None
        self._session = sess
        self.provider = sess.get_providers()[0]

    def unload(self) -> None:
        """Release the model (frees GPU memory)."""
        with self._lock:
            self._session = None
            self.provider = "not loaded"
        gc.collect()

    # --------------------------------------------------------------- inference
    def _target_size(self, h: int, w: int) -> Tuple[int, int]:
        if self._fixed_hw:
            return self._fixed_hw
        s = min(SHORT_SIDE / min(h, w), MAX_LONG_SIDE / max(h, w))
        return _round_to(h * s), _round_to(w * s)

    def _run(self, rgb: np.ndarray) -> np.ndarray:
        h, w = rgb.shape[:2]
        th, tw = self._target_size(h, w)
        img = np.clip(cv2.resize(rgb, (tw, th), interpolation=cv2.INTER_CUBIC), 0.0, 1.0)
        x = ((img - MEAN) / STD).transpose(2, 0, 1)[None].astype(
            np.float16 if "float16" in self._input_type else np.float32)
        out = self._session.run(None, {self._input_name: np.ascontiguousarray(x)})[0]
        return np.squeeze(out).astype(np.float32)

    def estimate(self, rgb: np.ndarray, progress: Progress = None) -> np.ndarray:
        with self._lock:
            if progress:
                progress(0.05, "Loading AI model")
            self.load()
            if progress:
                progress(0.3, f"Running AI depth on {self.device_label}")
            try:
                d = self._run(rgb)
                bad = (not np.isfinite(d).all()) or float(d.max() - d.min()) < 1e-6
            except Exception:
                if self.provider == "CPUExecutionProvider":
                    raise
                bad = True
            if bad and self.provider != "CPUExecutionProvider":
                # GPU failed or gave unusable numbers (older cards, low VRAM): retry on CPU
                self._session = None
                self.load(force_cpu=True)
                if progress:
                    progress(0.3, "GPU result unusable, retrying on CPU")
                d = self._run(rgb)

        if d.ndim != 2:
            raise RuntimeError(f"Unexpected model output shape {d.shape}")
        lo, hi = np.percentile(d, [0.5, 99.5])
        d = np.clip((d - lo) / max(float(hi - lo), 1e-6), 0.0, 1.0)
        d = cv2.resize(d, (rgb.shape[1], rgb.shape[0]), interpolation=cv2.INTER_CUBIC)
        if progress:
            progress(1.0, "AI depth ready")
        return np.clip(d, 0.0, 1.0).astype(np.float32)
