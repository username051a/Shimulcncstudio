"""Depth filters (all operate on float32 arrays in 0..1)."""
from __future__ import annotations

from typing import Optional

import cv2
import numpy as np

from .params import ProcessingMode, ReliefParams

REFERENCE_SIZE = 1024.0  # pixel-based settings are defined at a 1024-px reference size


def px_scale(nx: int, ny: int) -> float:
    """Converts 'px at 1024 reference' to px at the real working size."""
    return max(nx, ny) / REFERENCE_SIZE


def gaussian(img: np.ndarray, sigma: float) -> np.ndarray:
    if sigma <= 0.01:
        return img
    return cv2.GaussianBlur(img, (0, 0), sigmaX=float(sigma), sigmaY=float(sigma),
                            borderType=cv2.BORDER_REFLECT)


def highpass_detail(src: np.ndarray, sigma: float) -> np.ndarray:
    """High-pass layer normalised to about [-1, 1] (resolution independent)."""
    d = src - gaussian(src, max(sigma, 0.5))
    scale = max(float(np.percentile(np.abs(d[::2, ::2]), 99.5)), 0.02)
    return np.clip(d / scale, -1.0, 1.0).astype(np.float32)


def apply_levels(h: np.ndarray, black: int, white: int, gamma: float) -> np.ndarray:
    b, w = black / 255.0, white / 255.0
    x = np.clip((h - b) / (w - b), 0.0, 1.0)
    if abs(gamma - 1.0) > 1e-6:
        x = np.power(x, 1.0 / gamma)  # gamma > 1 lifts the mid-tones
    return x.astype(np.float32)


def trim_floor(h: np.ndarray, trim: int) -> np.ndarray:
    """Shave the lowest values and re-stretch (background trim)."""
    if trim <= 0:
        return h
    t = trim / 255.0
    return np.clip((h - t) / (1.0 - t), 0.0, 1.0).astype(np.float32)


def feather_mask(mask: np.ndarray, sigma: float) -> np.ndarray:
    return np.clip(gaussian(mask.astype(np.float32), sigma), 0.0, 1.0)


def apply_filters(
    depth: np.ndarray,
    detail_src: np.ndarray,
    mask: Optional[np.ndarray],
    p: ReliefParams,
    scale: float,
) -> np.ndarray:
    """Full depth-filter chain. Returns the final height map (0..1)."""
    coarse = gaussian(depth.astype(np.float32, copy=False), p.base_smooth * scale)

    need_detail = p.detail_only or p.mode == ProcessingMode.HIGH_PASS or p.groove_deepen > 0
    detail = highpass_detail(detail_src, p.highpass_radius * scale) if need_detail else None

    if p.detail_only:
        h = 0.5 + 0.5 * detail
    else:
        h = coarse + p.detail_strength * detail if p.mode == ProcessingMode.HIGH_PASS else coarse
        if p.groove_deepen > 0:
            h = h + p.groove_deepen * np.minimum(detail, 0.0)   # deepen valleys only
    h = np.clip(h, 0.0, 1.0)

    h = apply_levels(h, p.black_point, p.white_point, p.gamma)
    h = trim_floor(h, p.bg_trim)

    if mask is not None:                                          # force background to 0
        h = h * feather_mask(mask, p.mask_feather * scale)
    if p.negative:
        h = 1.0 - h
    return np.clip(h, 0.0, 1.0).astype(np.float32)
