"""Automatic foreground / background mask (1 = object, 0 = background)."""
from __future__ import annotations

from typing import Optional

import cv2
import numpy as np


def auto_foreground_mask(
    rgb: np.ndarray,
    alpha: Optional[np.ndarray],
    tolerance: float = 30.0,
    min_island: float = 0.00005,
) -> Optional[np.ndarray]:
    """Return a float32 mask, or None when no reliable mask can be found.

    1. If the image has transparency, the alpha channel is the mask.
    2. Otherwise the background colour is estimated from the image border and
       every pixel connected to the border within ``tolerance`` (0-255 colour
       distance) is background. Holes inside the object stay foreground.
    """
    if alpha is not None:
        return alpha.astype(np.float32)

    h, w = rgb.shape[:2]
    img = rgb * 255.0
    border = np.concatenate([img[0], img[-1], img[:, 0], img[:, -1]])
    bg = np.median(border, axis=0)
    if np.mean(np.linalg.norm(border - bg, axis=1) / np.sqrt(3.0) <= tolerance) < 0.5:
        return None  # border is not a uniform background

    dist = np.linalg.norm(img - bg, axis=2) / np.sqrt(3.0)
    cand = (dist <= tolerance).astype(np.uint8)
    _, labels = cv2.connectedComponents(cand, connectivity=4)
    border_labels = np.unique(np.concatenate([labels[0], labels[-1], labels[:, 0], labels[:, -1]]))
    border_labels = border_labels[border_labels != 0]
    background = np.isin(labels, border_labels)
    fg = (~background).astype(np.uint8)

    # drop tiny specks (JPEG noise etc.)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(fg, connectivity=8)
    small = stats[:, cv2.CC_STAT_AREA] < max(4, int(min_island * h * w))
    small[0] = False
    fg[small[lab]] = 0

    if fg.mean() < 0.002:
        return None  # nothing but background
    return fg.astype(np.float32)
