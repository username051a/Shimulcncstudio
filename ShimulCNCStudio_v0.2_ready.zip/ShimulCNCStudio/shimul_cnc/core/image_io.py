"""Image loading / saving (Unicode-path safe, handles 16-bit, alpha, EXIF)."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Union

import cv2
import numpy as np
from PIL import Image, ImageOps

Image.MAX_IMAGE_PIXELS = 300_000_000
MAX_LOAD_SIDE = 3072  # larger images are downscaled on load (keeps memory sane)


@dataclass
class LoadedImage:
    rgb: np.ndarray                      # float32 (H, W, 3), 0..1
    alpha: Optional[np.ndarray] = None   # float32 (H, W), 0..1; None when fully opaque
    source: str = ""

    @property
    def width(self) -> int:
        return int(self.rgb.shape[1])

    @property
    def height(self) -> int:
        return int(self.rgb.shape[0])


def _to_float01(a: np.ndarray) -> np.ndarray:
    if a.dtype == np.uint8:
        return a.astype(np.float32) / 255.0
    if a.dtype.kind == "u" and a.dtype.itemsize == 2:       # 16-bit
        return a.astype(np.float32) / 65535.0
    if a.dtype.kind in "iu":                                  # other integer types
        a = a.astype(np.float32)
        m = float(a.max()) if a.size else 0.0
        return a / m if m > 0 else a
    return np.clip(a.astype(np.float32), 0.0, 1.0)


def from_array(arr: np.ndarray, max_side: int = MAX_LOAD_SIDE, source: str = "") -> LoadedImage:
    a = _to_float01(np.asarray(arr))
    alpha = None
    if a.ndim == 3 and a.shape[2] == 1:
        a = a[:, :, 0]
    if a.ndim == 2:
        rgb = np.repeat(a[:, :, None], 3, axis=2)
    elif a.ndim == 3 and a.shape[2] == 2:                     # gray + alpha
        rgb = np.repeat(a[:, :, :1], 3, axis=2)
        alpha = a[:, :, 1]
    elif a.ndim == 3 and a.shape[2] == 3:
        rgb = a
    elif a.ndim == 3 and a.shape[2] == 4:
        rgb, alpha = a[:, :, :3], a[:, :, 3]
    else:
        raise ValueError(f"Unsupported image shape: {a.shape}")

    if alpha is not None and float(alpha.min()) >= 0.999:
        alpha = None  # fully opaque, ignore

    h, w = rgb.shape[:2]
    if max(h, w) > max_side:
        s = max_side / max(h, w)
        size = (max(2, round(w * s)), max(2, round(h * s)))
        rgb = cv2.resize(rgb, size, interpolation=cv2.INTER_AREA)
        if alpha is not None:
            alpha = cv2.resize(alpha, size, interpolation=cv2.INTER_AREA)

    return LoadedImage(
        rgb=np.ascontiguousarray(rgb, dtype=np.float32),
        alpha=None if alpha is None else np.ascontiguousarray(alpha, dtype=np.float32),
        source=source,
    )


def load_image(path: Union[str, Path], max_side: int = MAX_LOAD_SIDE) -> LoadedImage:
    path = Path(path)
    with Image.open(path) as im:
        try:
            im = ImageOps.exif_transpose(im)
        except Exception:
            pass
        if im.mode.startswith("I") or im.mode == "F":         # 16/32-bit grayscale
            arr = np.asarray(im)
        else:
            has_alpha = im.mode in ("RGBA", "LA", "PA", "RGBa", "La") or "transparency" in im.info
            arr = np.asarray(im.convert("RGBA" if has_alpha else "RGB"))
    return from_array(arr, max_side=max_side, source=str(path))


def save_png(path: Union[str, Path], arr: np.ndarray) -> None:
    """Save a float (0..1) or uint8 array as PNG (Unicode-path safe)."""
    a = np.asarray(arr)
    if a.dtype != np.uint8:
        a = np.clip(a, 0.0, 1.0)
        a = (a * 255.0 + 0.5).astype(np.uint8)
    Image.fromarray(a).save(Path(path), format="PNG")
