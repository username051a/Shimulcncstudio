"""Relief generation parameters.

Every field maps 1:1 to a control of the future UI, so the UI can simply build
a ``ReliefParams`` object and hand it to the engine.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, fields
from enum import Enum


class ProcessingMode(str, Enum):
    DIRECT = "direct"        # depth is used as it is (optionally smoothed)
    HIGH_PASS = "high_pass"  # coarse depth + high-pass detail taken from the source image


# Mesh detail level -> target triangle count ("Level 1" ~ 2M triangles).
MESH_LEVELS: dict[int, int] = {
    1: 2_000_000,
    2: 1_000_000,
    3: 500_000,
    4: 250_000,
    5: 100_000,
}


@dataclass
class ReliefParams:
    # ---- physical size (mm) -------------------------------------------------
    width_mm: float = 100.0          # X size. Y size follows the image aspect ratio.
    relief_height_mm: float = 3.0    # height of the relief above the base plate
    base_mm: float = 3.0             # thickness of the solid base plate
    negative: bool = False           # negative / intaglio: heights are inverted
    floor_lift_mm: float = 0.1       # lowest relief surface sits this much above the base top

    # ---- depth ---------------------------------------------------------------
    invert_depth: bool = False       # swap near/far (dark = high)

    # ---- depth filter --------------------------------------------------------
    mode: ProcessingMode = ProcessingMode.HIGH_PASS
    highpass_radius: float = 6.0     # detail scale (px at a 1024-px reference size)
    detail_strength: float = 0.2     # how strongly the high-pass detail is added
    base_smooth: float = 0.0         # blur of the coarse depth (px at 1024 reference)
    groove_deepen: float = 0.0       # extra depth in valleys / dark creases
    detail_only: bool = False        # use only the detail layer (fine engraving)

    # ---- background mask -----------------------------------------------------
    use_mask: bool = True            # force the background to zero height
    mask_tolerance: float = 30.0     # colour distance (0-255) treated as background
    mask_feather: float = 1.0        # edge softening of the mask (px at 1024 reference)
    bg_trim: int = 3                 # shave the lowest values (0-255)

    # ---- 3D levels -----------------------------------------------------------
    black_point: int = 0
    gamma: float = 1.0
    white_point: int = 255

    # ---- mesh ----------------------------------------------------------------
    mesh_level: int = 1              # key of MESH_LEVELS

    def validate(self) -> "ReliefParams":
        def need(cond: bool, msg: str) -> None:
            if not cond:
                raise ValueError(msg)

        need(self.width_mm > 0, "Width must be greater than 0 mm.")
        need(self.relief_height_mm > 0, "Relief height must be greater than 0 mm.")
        need(self.base_mm >= 0, "Base thickness cannot be negative.")
        need(0 <= self.floor_lift_mm < self.relief_height_mm,
             "Floor lift must be >= 0 and smaller than the relief height.")
        need(self.base_mm + self.floor_lift_mm >= 0.05,
             "Base thickness + floor lift must be at least 0.05 mm (a solid needs thickness).")
        need(0 <= self.black_point < self.white_point <= 255,
             "Levels: black point must be lower than white point (0-255).")
        need(0.1 <= self.gamma <= 10, "Gamma must be between 0.1 and 10.")
        need(self.mesh_level in MESH_LEVELS, f"Mesh level must be one of {sorted(MESH_LEVELS)}.")
        need(self.highpass_radius > 0, "High-pass radius must be greater than 0.")
        need(self.detail_strength >= 0 and self.groove_deepen >= 0 and self.base_smooth >= 0,
             "Detail strength, groove deepen and base smooth cannot be negative.")
        need(0 <= self.bg_trim <= 254, "Background trim must be between 0 and 254.")
        need(0 <= self.mask_tolerance <= 255, "Mask tolerance must be between 0 and 255.")
        need(self.mask_feather >= 0, "Mask feather cannot be negative.")
        return self

    # ---- presets / project files --------------------------------------------
    def to_dict(self) -> dict:
        d = asdict(self)
        d["mode"] = self.mode.value
        return d

    @classmethod
    def from_dict(cls, data: dict) -> "ReliefParams":
        known = {f.name for f in fields(cls)}
        clean = {k: v for k, v in data.items() if k in known}
        if "mode" in clean:
            clean["mode"] = ProcessingMode(clean["mode"])
        return cls(**clean).validate()
