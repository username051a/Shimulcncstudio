"""Fast binary STL writer / reader (numpy, chunked, atomic write)."""
from __future__ import annotations

import os
from pathlib import Path
from typing import Callable, Optional, Union

import numpy as np

from .mesh import Mesh

Progress = Optional[Callable[[float, str], None]]

_REC = np.dtype([("normal", "<f4", (3,)), ("v", "<f4", (3, 3)), ("attr", "<u2")])
assert _REC.itemsize == 50

_HEADER = b"Shimul CNC Studio - binary STL"   # must not start with 'solid'


def write_binary_stl(
    path: Union[str, Path],
    mesh: Mesh,
    progress: Progress = None,
    chunk: int = 200_000,
) -> int:
    """Write ``mesh`` as binary STL. Returns the file size in bytes."""
    path = Path(path)
    tmp = path.with_name(path.name + ".tmp")
    n = mesh.n_faces
    try:
        with open(tmp, "wb") as f:
            f.write(_HEADER.ljust(80, b"\0"))
            f.write(np.uint32(n).tobytes())
            for s in range(0, n, chunk):
                tri = mesh.vertices[mesh.faces[s:s + chunk]]            # (k, 3, 3) float32
                nrm = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
                ln = np.linalg.norm(nrm, axis=1, keepdims=True)
                nrm = np.divide(nrm, ln, out=np.zeros_like(nrm), where=ln > 0)
                rec = np.empty(tri.shape[0], dtype=_REC)
                rec["normal"] = nrm
                rec["v"] = tri
                rec["attr"] = 0
                f.write(rec.tobytes())
                if progress:
                    progress(min(1.0, (s + chunk) / n), "Writing STL")
        os.replace(tmp, path)
    except BaseException:
        try:
            if tmp.exists():
                tmp.unlink()
        except OSError:
            pass
        raise
    return 84 + 50 * n


def read_binary_stl(path: Union[str, Path]) -> np.ndarray:
    """Read a binary STL. Returns triangles as float32 array (M, 3, 3)."""
    data = Path(path).read_bytes()
    n = int(np.frombuffer(data, dtype="<u4", count=1, offset=80)[0])
    if len(data) != 84 + 50 * n:
        raise ValueError("Not a valid binary STL (size mismatch).")
    rec = np.frombuffer(data, dtype=_REC, count=n, offset=84)
    return np.array(rec["v"])
