"""Quick 2D shaded preview of a height map (used for tests and as a UI fallback)."""
from __future__ import annotations

import numpy as np


def hillshade(z_mm: np.ndarray, dx: float, dy: float,
              azimuth_deg: float = 315.0, altitude_deg: float = 40.0,
              z_exaggeration: float = 1.0) -> np.ndarray:
    """Lambert shading of a height field. Returns uint8 (H, W)."""
    z = z_mm.astype(np.float32) * z_exaggeration
    dz_dx = np.gradient(z, dx, axis=1)
    dz_dy = -np.gradient(z, dy, axis=0)                # image rows go down, Y goes up
    nrm = np.sqrt(dz_dx ** 2 + dz_dy ** 2 + 1.0)
    az, alt = np.radians(azimuth_deg), np.radians(altitude_deg)
    lx, ly, lz = np.cos(alt) * np.sin(az), np.cos(alt) * np.cos(az), np.sin(alt)
    shade = (-dz_dx * lx - dz_dy * ly + lz) / nrm
    return (np.clip(shade, 0.0, 1.0) * 255.0 + 0.5).astype(np.uint8)
