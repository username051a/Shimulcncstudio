"""Depth sources.

A depth source turns an RGB image into a float32 map in 0..1 where
bright = high / near. The AI source (Depth Anything V2 Small, ONNX) plugs in
here later through the same ``DepthSource`` interface.
"""
from __future__ import annotations

from typing import Callable, Optional

import numpy as np

Progress = Optional[Callable[[float, str], None]]


def luminance(rgb: np.ndarray) -> np.ndarray:
    """Rec.709 luminance of a float RGB image."""
    return (rgb[..., 0] * 0.2126 + rgb[..., 1] * 0.7152 + rgb[..., 2] * 0.0722).astype(np.float32)


class DepthSource:
    name = "base"

    def estimate(self, rgb: np.ndarray, progress: Progress = None) -> np.ndarray:
        raise NotImplementedError


class GrayscaleDepth(DepthSource):
    """Manual mode: image brightness is the height (white = high)."""

    name = "Grayscale (manual)"

    def estimate(self, rgb: np.ndarray, progress: Progress = None) -> np.ndarray:
        return luminance(rgb)
