"""High level relief pipeline.

    load_image -> analyse (depth, slow with AI, cacheable)
               -> render_relief (filters + mesh, fast, re-run when sliders move)

``generate_relief`` chains both for one-shot use (CLI, batch).
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, List, Optional, Tuple, Union

import cv2
import numpy as np

from .depth_sources import DepthSource, GrayscaleDepth, luminance
from .filters import apply_filters, px_scale
from .image_io import LoadedImage, from_array, load_image
from .masking import auto_foreground_mask
from .mesh import Mesh, build_solid_mesh
from .params import MESH_LEVELS, ReliefParams

Progress = Optional[Callable[[float, str], None]]
ImageLike = Union[str, Path, LoadedImage, np.ndarray]


def _report(cb: Progress, frac: float, msg: str) -> None:
    if cb:
        cb(frac, msg)


@dataclass
class Analysis:
    """Result of the (possibly slow) depth estimation. Cache this in the UI."""
    image: LoadedImage
    depth: np.ndarray            # float32 (H, W), 0..1, bright = high
    depth_name: str = ""


@dataclass
class ReliefStats:
    grid: Tuple[int, int]                   # (nx, ny)
    vertices: int
    faces: int
    stl_bytes: int
    size_mm: Tuple[float, float, float]     # X, Y, Z (total height incl. base)
    elapsed_s: float


@dataclass
class ReliefResult:
    mesh: Mesh
    depth: np.ndarray                       # final height map 0..1 ("Final Mixed Depth")
    z_mm: np.ndarray                        # top surface heights in mm
    mask: Optional[np.ndarray]
    stats: ReliefStats
    notes: List[str] = field(default_factory=list)


def _as_image(image: ImageLike) -> LoadedImage:
    if isinstance(image, LoadedImage):
        return image
    if isinstance(image, (str, Path)):
        return load_image(image)
    return from_array(image)


def compute_grid(src_w: int, src_h: int, level: int) -> Tuple[int, int]:
    """Grid size (nx, ny) for a mesh level: ~target triangles, never above source size."""
    target_faces = MESH_LEVELS[level]
    aspect = src_w / src_h
    ny = math.sqrt(target_faces / 2.0 / aspect)
    nx = ny * aspect
    s = min(1.0, src_w / nx, src_h / ny)
    return max(2, round(nx * s)), max(2, round(ny * s))


def estimate_mesh_stats(src_w: int, src_h: int, level: int) -> Tuple[int, int, int, int, int]:
    """Exact (nx, ny, vertices, faces, stl_bytes) of a mesh level, without building it."""
    nx, ny = compute_grid(src_w, src_h, level)
    per = 2 * nx + 2 * ny - 4
    vertices = nx * ny + per + 1
    faces = 2 * (nx - 1) * (ny - 1) + 3 * per
    return nx, ny, vertices, faces, 84 + 50 * faces


def analyse(image: ImageLike, depth_source: Optional[DepthSource] = None,
            progress: Progress = None) -> Analysis:
    img = _as_image(image)
    src = depth_source or GrayscaleDepth()
    _report(progress, 0.0, f"Estimating depth ({src.name})")
    depth = np.clip(src.estimate(img.rgb, progress), 0.0, 1.0).astype(np.float32)
    if depth.shape != img.rgb.shape[:2]:
        depth = cv2.resize(depth, (img.width, img.height), interpolation=cv2.INTER_CUBIC)
    return Analysis(img, depth, src.name)


def _resize(a: np.ndarray, nx: int, ny: int) -> np.ndarray:
    shrinking = nx < a.shape[1] or ny < a.shape[0]
    return cv2.resize(a, (nx, ny), interpolation=cv2.INTER_AREA if shrinking else cv2.INTER_CUBIC)


def heights_to_mm(h: np.ndarray, p: ReliefParams) -> np.ndarray:
    lift = p.floor_lift_mm
    return (p.base_mm + lift + h * (p.relief_height_mm - lift)).astype(np.float32)


def render_relief(analysis: Analysis, params: ReliefParams,
                  mask: Optional[np.ndarray] = None,
                  progress: Progress = None) -> ReliefResult:
    """Apply filters and build the mesh. Fast enough to re-run on every slider change."""
    t0 = time.perf_counter()
    p = params.validate()
    img = analysis.image
    notes: List[str] = []

    nx, ny = compute_grid(img.width, img.height, p.mesh_level)
    _report(progress, 0.05, f"Resampling to {nx} x {ny}")
    rgb = _resize(img.rgb, nx, ny)
    depth = _resize(analysis.depth, nx, ny)
    if p.invert_depth:
        depth = 1.0 - depth
    gray = luminance(rgb)

    m = None
    if p.use_mask:
        if mask is not None:
            m = np.clip(_resize(mask.astype(np.float32), nx, ny), 0.0, 1.0)
        else:
            alpha = None if img.alpha is None else _resize(img.alpha, nx, ny)
            m = auto_foreground_mask(rgb, alpha, p.mask_tolerance)
            if m is None:
                notes.append("No clear background found: mask skipped (border is not a uniform colour).")

    _report(progress, 0.25, "Applying depth filters")
    h = apply_filters(depth, gray, m, p, px_scale(nx, ny))

    _report(progress, 0.55, "Building mesh")
    size_x = p.width_mm
    size_y = p.width_mm * img.height / img.width
    z_mm = heights_to_mm(h, p)
    mesh = build_solid_mesh(z_mm, size_x, size_y)

    stats = ReliefStats((nx, ny), mesh.n_vertices, mesh.n_faces, mesh.stl_size_bytes,
                        (size_x, size_y, float(z_mm.max())), time.perf_counter() - t0)
    _report(progress, 1.0, "Mesh ready")
    return ReliefResult(mesh, h, z_mm, m, stats, notes)


def generate_relief(image: ImageLike, params: ReliefParams,
                    depth_source: Optional[DepthSource] = None,
                    mask: Optional[np.ndarray] = None,
                    progress: Progress = None) -> ReliefResult:
    params.validate()
    analysis = analyse(image, depth_source, progress)
    return render_relief(analysis, params, mask, progress)
