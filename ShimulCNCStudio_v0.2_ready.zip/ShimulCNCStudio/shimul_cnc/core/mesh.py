"""Heightfield -> closed (watertight) solid mesh.

Coordinates: X to the right, Y up (image top = max Y), Z up. The solid sits on
the plane Z = 0; the top surface follows the height map.

Triangle winding is counter-clockwise seen from outside, so normals point out.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import numpy as np


@dataclass
class Mesh:
    vertices: np.ndarray               # (N, 3) float32
    faces: np.ndarray                  # (M, 3) int32
    grid_shape: Tuple[int, int]        # (ny, nx) of the top surface grid
    size_mm: Tuple[float, float, float]

    @property
    def n_vertices(self) -> int:
        return int(self.vertices.shape[0])

    @property
    def n_faces(self) -> int:
        return int(self.faces.shape[0])

    @property
    def stl_size_bytes(self) -> int:
        return 84 + 50 * self.n_faces


def build_solid_mesh(z_top: np.ndarray, size_x: float, size_y: float) -> Mesh:
    """Build the solid from top-surface heights ``z_top`` (ny, nx) in mm."""
    z_top = np.ascontiguousarray(z_top, dtype=np.float32)
    ny, nx = z_top.shape
    if nx < 2 or ny < 2:
        raise ValueError("Height map must be at least 2 x 2.")

    # ---- top surface vertices ------------------------------------------------
    xs = np.linspace(0.0, size_x, nx, dtype=np.float32)
    ys = np.linspace(size_y, 0.0, ny, dtype=np.float32)          # row 0 = max Y
    top = np.empty((ny, nx, 3), dtype=np.float32)
    top[..., 0] = xs[None, :]
    top[..., 1] = ys[:, None]
    top[..., 2] = z_top
    n_top = nx * ny
    idx = np.arange(n_top, dtype=np.int32).reshape(ny, nx)

    # ---- top surface triangles (normal +Z) ----------------------------------
    a = idx[:-1, :-1].ravel()   # top-left
    b = idx[:-1, 1:].ravel()    # top-right
    c = idx[1:, :-1].ravel()    # bottom-left
    d = idx[1:, 1:].ravel()     # bottom-right
    top_faces = np.empty((2 * a.size, 3), dtype=np.int32)
    top_faces[0::2] = np.stack((c, d, b), axis=1)
    top_faces[1::2] = np.stack((c, b, a), axis=1)

    # ---- perimeter, counter-clockwise seen from above ------------------------
    per = np.concatenate([
        idx[ny - 1, :],             # bottom edge, left -> right
        idx[ny - 2::-1, nx - 1],    # right edge, going up
        idx[0, nx - 2::-1],         # top edge, right -> left
        idx[1:ny - 1, 0],           # left edge, going down
    ]).astype(np.int32)
    n_per = per.size

    # bottom perimeter vertices (z = 0) + one centre vertex for the bottom fan
    bottom = top.reshape(-1, 3)[per].copy()
    bottom[:, 2] = 0.0
    centre = np.array([[size_x / 2.0, size_y / 2.0, 0.0]], dtype=np.float32)
    vertices = np.concatenate([top.reshape(-1, 3), bottom, centre], axis=0)

    i = np.arange(n_per, dtype=np.int32)
    j = (i + 1) % n_per
    t_i, t_j = per, per[j]
    b_i, b_j = n_top + i, n_top + j
    c_idx = np.full(n_per, n_top + n_per, dtype=np.int32)

    # ---- side walls (outward normals) and bottom (normal -Z) -----------------
    walls = np.empty((2 * n_per, 3), dtype=np.int32)
    walls[0::2] = np.stack((b_i, b_j, t_j), axis=1)
    walls[1::2] = np.stack((b_i, t_j, t_i), axis=1)
    bottom_faces = np.stack((c_idx, b_j, b_i), axis=1)

    faces = np.concatenate([top_faces, walls, bottom_faces], axis=0)
    return Mesh(vertices, faces, (ny, nx), (float(size_x), float(size_y), float(z_top.max())))


def signed_volume(mesh: Mesh, chunk: int = 500_000) -> float:
    """Volume of the closed mesh in mm^3 (positive when normals point outward)."""
    total = 0.0
    for s in range(0, mesh.n_faces, chunk):
        tri = mesh.vertices[mesh.faces[s:s + chunk]].astype(np.float64)
        total += float(np.einsum("ij,ij->i", tri[:, 0], np.cross(tri[:, 1], tri[:, 2])).sum())
    return total / 6.0
