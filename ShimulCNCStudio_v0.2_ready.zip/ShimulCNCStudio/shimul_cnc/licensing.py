"""License hook.

The free edition has no restrictions. When the software is sold later, a real
check (license key / account) goes into ``check_license`` and the UI keeps
working unchanged because it only talks to this module.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class LicenseInfo:
    edition: str = "Free edition"
    valid: bool = True
    owner: str = ""


def check_license() -> LicenseInfo:
    return LicenseInfo()
