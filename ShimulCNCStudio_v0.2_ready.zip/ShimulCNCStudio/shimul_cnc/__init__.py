APP_NAME = "Shimul CNC Studio"
__version__ = "0.2.0"
