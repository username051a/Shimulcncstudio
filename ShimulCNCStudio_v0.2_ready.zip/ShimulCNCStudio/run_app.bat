@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Shimul CNC Studio
set "PY="
for %%V in (3.12 3.13 3.11 3.10) do (
  if not defined PY (
    py -%%V -c "import sys" >nul 2>&1 && set "PY=py -%%V"
  )
)
if not defined PY (
  python -c "import sys" >nul 2>&1 && set "PY=python"
)
if not defined PY goto :nopython

if not exist ".venv\Scripts\python.exe" (
  echo Creating a private Python environment ...
  %PY% -m venv .venv || goto :fail
)
if not exist ".venv\.deps_ok" (
  echo Installing the required libraries. This happens once and needs internet ...
  ".venv\Scripts\python.exe" -m pip install --upgrade pip >nul 2>&1
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt || goto :pipfail
  echo ok>".venv\.deps_ok"
)
".venv\Scripts\python.exe" run.py %*
if errorlevel 1 goto :fail
exit /b 0

:nopython
echo.
echo Python was not found.
echo Please install Python 3.12 (64-bit) from https://www.python.org/downloads/windows/
echo and tick "Add python.exe to PATH" during setup. Then run this file again.
pause
exit /b 1

:pipfail
echo.
echo Installing the libraries failed.
echo The most common reason is a very new Python version without ready-made packages.
echo Please install Python 3.12 (64-bit) from https://www.python.org/downloads/windows/
echo then delete the ".venv" folder here and run this file again.
pause
exit /b 1

:fail
echo.
echo Something went wrong. Details are saved in:
echo %LOCALAPPDATA%\ShimulCNCStudio\app.log
pause
exit /b 1
