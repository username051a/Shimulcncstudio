@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Build Shimul CNC Studio
echo ============================================================
echo  Shimul CNC Studio - build the Windows program and installer
echo ============================================================
set "PY="
for %%V in (3.12 3.13 3.11 3.10) do (
  if not defined PY (
    py -%%V -c "import sys" >nul 2>&1 && set "PY=py -%%V"
  )
)
if not defined PY (
  python -c "import sys" >nul 2>&1 && set "PY=python"
)
if not defined PY (
  echo Python was not found. Install Python 3.12 ^(64-bit^) from https://www.python.org/downloads/windows/
  pause
  exit /b 1
)

if not exist ".venv-build\Scripts\python.exe" (
  echo [1/6] Creating build environment ...
  %PY% -m venv .venv-build || goto :fail
)
set "VPY=.venv-build\Scripts\python.exe"
echo [2/6] Installing libraries ^(first time needs internet^) ...
"%VPY%" -m pip install --upgrade pip >nul 2>&1
"%VPY%" -m pip install -r requirements-build.txt || goto :fail

echo [3/6] Downloading the free AI model so the installer works offline ...
"%VPY%" tools\fetch_model.py

echo [4/6] Running tests ...
set QT_QPA_PLATFORM=offscreen
"%VPY%" -m pytest -q tests
set QT_QPA_PLATFORM=
if errorlevel 1 echo WARNING: some tests failed. Continuing, but please report this.

echo [5/6] Building the program ...
"%VPY%" -m PyInstaller packaging\ShimulCNCStudio.spec --noconfirm --clean || goto :fail
start "" /wait dist\ShimulCNCStudio\ShimulCNCStudio.exe --selftest dist\selftest.txt
type dist\selftest.txt

echo [6/6] Building the installer ...
set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
if defined ISCC (
  "%ISCC%" packaging\installer.iss || goto :fail
  echo.
  echo DONE. Installer:  dist\ShimulCNCStudio_Setup_*.exe
) else (
  powershell -NoProfile -Command "Compress-Archive -Force -Path dist\ShimulCNCStudio -DestinationPath dist\ShimulCNCStudio_portable.zip"
  echo.
  echo DONE. Portable program: dist\ShimulCNCStudio\ShimulCNCStudio.exe
  echo       Portable zip:     dist\ShimulCNCStudio_portable.zip
  echo For a setup installer, install the free "Inno Setup 6" from https://jrsoftware.org/isinfo.php and run this file again.
)
pause
exit /b 0

:fail
echo.
echo The build stopped because of an error. Please send the text above to your developer.
pause
exit /b 1
