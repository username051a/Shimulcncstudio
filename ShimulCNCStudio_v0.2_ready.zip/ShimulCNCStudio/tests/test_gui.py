"""End-to-end GUI tests. Run headless (QT_QPA_PLATFORM=offscreen) or under Xvfb.

OpenGL may be missing on CI machines: the viewport then switches to its 2D fallback,
and everything else must still work, which is exactly what these tests check.
"""
import os
import sys
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(Path(__file__).resolve().parent))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

pytest.importorskip("PySide6")
from PySide6.QtCore import QSettings
from PySide6.QtWidgets import QApplication

from gui_harness import pump, silence_dialogs, wait_until
from shimul_cnc.core import save_png
from shimul_cnc.ui.main_window import MainWindow
from shimul_cnc.ui.state import AppState
from shimul_cnc.ui.theme import apply_theme
from synthetic import emblem


@pytest.fixture(scope="module")
def app():
    a = QApplication.instance() or QApplication([])
    apply_theme(a)
    return a


@pytest.fixture()
def win(app, tmp_path, monkeypatch):
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "appdata"))
    QSettings("ShimulCNC", "Studio").clear()
    calls = silence_dialogs()
    state = AppState()
    state.model_path = None
    state.depth_mode = "gray"
    w = MainWindow(state, force_software=os.environ.get("QT_QPA_PLATFORM") == "offscreen")
    w.show()
    pump(app, 0.3)
    w.calls = calls
    w.img = tmp_path / "ছবি emblem.png"                  # Unicode + space in the path on purpose
    save_png(w.img, emblem(600, 800))
    yield w
    w.close()


def idle(app, state):
    wait_until(app, lambda: state._job is None and not state._queue, what="idle")


def test_open_edit_export(app, win, tmp_path):
    s = win.state
    win.load_path(str(win.img))
    wait_until(app, lambda: s.result is not None, what="first preview")
    idle(app, s)
    assert s.final.width == 600 and s.result.mesh.n_faces > 400_000
    assert any(c[0] == "question" for c in win.calls)            # offered the AI download once

    before = id(s.result)
    s.set_param("relief_height_mm", 5.0)
    wait_until(app, lambda: id(s.result) != before, what="slider re-render")
    assert s.result.stats.size_mm[2] == pytest.approx(8.0, abs=1e-3)

    s.set_param("black_point", 250)
    s.set_param("white_point", 100)                              # impossible levels get repaired
    assert s.params.black_point < s.params.white_point

    win.crop.view.set_crop(50, 60, 300, 400)
    win.crop.btn_apply.click()
    wait_until(app, lambda: s.final.width == 300, what="crop")
    idle(app, s)
    s.transform("flip_h")
    wait_until(app, lambda: s.base.width == 600, what="flip")
    idle(app, s)

    s.set_param("mesh_level", 4)
    out = tmp_path / "ফলাফল.stl"
    done = []
    s.exported.connect(lambda p, n: done.append((p, n)))
    win.btn_export_top.click() if False else s.export_stl(out)
    wait_until(app, lambda: done, what="export")
    assert out.stat().st_size == done[0][1]
    trimesh = pytest.importorskip("trimesh")
    m = trimesh.load(str(out), force="mesh")
    assert m.is_watertight and m.is_winding_consistent and m.volume > 0


def test_viewport_controls_never_crash(app, win):
    win.load_path(str(win.img))
    wait_until(app, lambda: win.state.result is not None, what="preview")
    vp = win.mesh.vp
    for fn in (lambda: vp.rotate_x(90), lambda: vp.rotate_x(-90), lambda: vp.rotate_z(90), vp.reset_view,
               lambda: vp.set_mode("normal"), lambda: vp.set_mode("texture"), lambda: vp.set_wire(True)):
        fn()
        pump(app, 0.05)
    assert -90 <= vp.pitch <= 90


def test_pages_and_presets(app, win, tmp_path):
    s = win.state
    for i in (0, 1, 2):
        win.show_page(i)
        pump(app, 0.1)
    s.set_param("gamma", 1.6)
    s.save_preset(tmp_path / "p.json")
    s.reset_params()
    assert s.params.gamma == 1.0
    s.load_preset(tmp_path / "p.json")
    assert s.params.gamma == pytest.approx(1.6)
    assert win.mesh._ctrl["gamma"].value() == pytest.approx(1.6)  # widgets follow the state


def test_ai_mode_with_model_and_fallbacks(app, win, tmp_path):
    pytest.importorskip("onnx")
    from test_ai import make_fake_model
    s = win.state
    s.model_path = make_fake_model(tmp_path / "m.onnx")
    s.set_depth_mode("ai")
    win.load_path(str(win.img))
    wait_until(app, lambda: s.analysis is not None and s.analysis.depth_name.startswith("AI") and s.result is not None,
               what="AI depth")
    idle(app, s)
    s.free_vram()
    assert not s.ai.loaded
    # a corrupt model must not crash: fall back to grayscale and tell the user
    bad = tmp_path / "bad.onnx"
    bad.write_bytes(b"x" * 6_000_000)
    s.model_path, s.ai = bad, None
    win.calls.clear()
    s.run_ai_depth()
    wait_until(app, lambda: s.depth_mode == "gray" and s._job is None, what="fallback")
    assert any(c[0] == "warning" for c in win.calls)
