import functools
import http.server
import socketserver
import sys
import threading
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))

onnx = pytest.importorskip("onnx")
pytest.importorskip("onnxruntime")
from onnx import TensorProto, helper

from shimul_cnc.ai import DepthAnythingOnnx, ModelError, download_model
from shimul_cnc.core import ReliefParams, analyse, generate_relief, render_relief
from synthetic import emblem


def make_fake_model(path, fixed=None):
    """Same interface as the real model: pixel_values (1,3,H,W) -> predicted_depth (1,H,W)."""
    h, w = fixed if fixed else ("height", "width")
    x = helper.make_tensor_value_info("pixel_values", TensorProto.FLOAT, [1, 3, h, w])
    y = helper.make_tensor_value_info("predicted_depth", TensorProto.FLOAT, [1, h, w])
    node = helper.make_node("ReduceMean", ["pixel_values"], ["predicted_depth"], axes=[1], keepdims=0)
    g = helper.make_graph([node], "fake_dav2", [x], [y])
    m = helper.make_model(g, opset_imports=[helper.make_opsetid("", 13)])
    m.ir_version = 8
    onnx.save(m, str(path))
    return path


def test_dynamic_shape_model(tmp_path):
    src = DepthAnythingOnnx(make_fake_model(tmp_path / "m.onnx"))
    img = emblem(300, 500)
    d = src.estimate(img)
    assert d.shape == (500, 300) and d.dtype == np.float32
    assert 0.0 <= d.min() and d.max() <= 1.0 and d.max() > 0.9      # normalised to full range
    assert src.device_label in ("CPU", "GPU (DirectML)", "GPU (CUDA)")        # depends on the machine
    # fake model = channel mean, so the emblem body must be brighter than the blue background
    assert d[250, 150] > d[5, 5] + 0.2
    src.unload()
    assert not src.loaded


def test_fixed_shape_model_is_resized(tmp_path):
    src = DepthAnythingOnnx(make_fake_model(tmp_path / "f.onnx", fixed=(518, 518)))
    d = src.estimate(emblem(400, 250))
    assert d.shape == (250, 400)


def test_target_size_rules():
    s = DepthAnythingOnnx(Path("x"))
    for h, w in [(800, 600), (600, 800), (300, 3000), (4000, 4000), (100, 100)]:
        th, tw = s._target_size(h, w)
        assert th % 14 == 0 and tw % 14 == 0 and max(th, tw) <= 1036 + 14


def test_ai_depth_feeds_the_relief_pipeline(tmp_path):
    src = DepthAnythingOnnx(make_fake_model(tmp_path / "m.onnx"))
    analysis = analyse(emblem(400, 500), src)
    assert analysis.depth_name.startswith("AI")
    r = render_relief(analysis, ReliefParams(mesh_level=4))
    assert r.mesh.n_faces > 200_000 and r.depth.max() > 0.3


def test_download_with_local_server(tmp_path):
    payload = b"x" * 2_000_000
    web = tmp_path / "web"
    web.mkdir()
    (web / "model.onnx").write_bytes(payload)
    handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(web))
    handler.log_message = lambda *a, **k: None
    with socketserver.TCPServer(("127.0.0.1", 0), handler) as srv:
        port = srv.server_address[1]
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        seen = []
        out = download_model(progress=lambda f, m: seen.append(f), urls=[f"http://127.0.0.1:{port}/model.onnx"],
                             min_bytes=1_000_000, dest_dir=tmp_path / "dl")
        assert out.read_bytes() == payload and seen and seen[-1] == 1.0
        assert not list((tmp_path / "dl").glob("*.part"))
        # first URL dead -> falls back to the second
        out2 = download_model(urls=["http://127.0.0.1:1/nope", f"http://127.0.0.1:{port}/model.onnx"],
                              min_bytes=1_000_000, dest_dir=tmp_path / "dl2")
        assert out2.exists()
        # too small -> rejected
        with pytest.raises(ModelError):
            download_model(urls=[f"http://127.0.0.1:{port}/model.onnx"], min_bytes=5_000_000, dest_dir=tmp_path / "dl3")
        srv.shutdown()


def test_bad_gpu_output_falls_back_to_cpu(tmp_path):
    """If a GPU provider returns NaN, the engine must retry on CPU instead of returning garbage."""
    src = DepthAnythingOnnx(make_fake_model(tmp_path / "m.onnx"))
    src.load()
    real_run = src._run
    calls = {"n": 0}

    def flaky(rgb):
        calls["n"] += 1
        return np.full((70, 70), np.nan, np.float32) if calls["n"] == 1 else real_run(rgb)

    src._run = flaky
    src.provider = "DmlExecutionProvider"           # pretend we are on the GPU
    d = src.estimate(emblem(200, 200))
    assert np.isfinite(d).all() and d.max() > 0.9 and src.provider == "CPUExecutionProvider"
