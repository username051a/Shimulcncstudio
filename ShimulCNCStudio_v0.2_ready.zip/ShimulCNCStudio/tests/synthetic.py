"""Synthetic test images (no external files needed)."""
import numpy as np

BLUE = np.array([13, 89, 217], dtype=np.float32) / 255.0


def emblem(w: int = 600, h: int = 800, seed: int = 1) -> np.ndarray:
    """A dome with radial petals and fine ripples on a blue background (float RGB 0..1)."""
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    cx, cy = w / 2, h / 2
    r = np.hypot((xx - cx) / (w * 0.38), (yy - cy) / (h * 0.30))
    ang = np.arctan2(yy - cy, xx - cx)
    body = np.clip(1 - r ** 2, 0, 1)
    petals = 0.5 + 0.5 * np.cos(8 * ang)
    ripple = 0.5 + 0.5 * np.cos(r * 40)
    lum = np.clip(0.25 + 0.5 * body + 0.15 * petals * body + 0.10 * ripple * body, 0, 1)
    rgb = np.empty((h, w, 3), np.float32)
    rgb[:] = BLUE
    inside = r < 1
    rgb[inside] = lum[inside, None]
    rng = np.random.default_rng(seed)
    rgb += rng.normal(0, 0.008, rgb.shape).astype(np.float32)     # sensor / JPEG-like noise
    return np.clip(rgb, 0, 1)
