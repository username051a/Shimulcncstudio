import sys
import time
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from shimul_cnc.core import (MESH_LEVELS, ProcessingMode, ReliefParams, build_solid_mesh, compute_grid,
                             generate_relief, load_image, read_binary_stl, save_png, signed_volume,
                             write_binary_stl, from_array)
from shimul_cnc.core.masking import auto_foreground_mask
from synthetic import emblem


# ---------------------------------------------------------------- helpers --
def assert_closed_oriented_manifold(faces: np.ndarray, n_vertices: int) -> None:
    """Every directed edge appears exactly once and has its reverse -> closed, consistently oriented."""
    e = np.concatenate([faces[:, [0, 1]], faces[:, [1, 2]], faces[:, [2, 0]]]).astype(np.int64)
    fwd = e[:, 0] * n_vertices + e[:, 1]
    rev = e[:, 1] * n_vertices + e[:, 0]
    assert len(np.unique(fwd)) == len(fwd), "a directed edge is used more than once"
    assert np.array_equal(np.sort(fwd), np.sort(rev)), "an edge has no opposite edge (hole)"


def volume_under_surface(z, dx, dy):
    a, b, c, d = z[:-1, :-1], z[:-1, 1:], z[1:, :-1], z[1:, 1:]
    return float(np.sum(dx * dy / 2 * (c + d + b) / 3 + dx * dy / 2 * (c + b + a) / 3))


# ----------------------------------------------------------------- params --
def test_params_validation_and_roundtrip():
    p = ReliefParams()
    assert ReliefParams.from_dict(p.to_dict()) == p
    for bad in (dict(width_mm=0), dict(black_point=200, white_point=100), dict(gamma=0),
                dict(mesh_level=9), dict(base_mm=0, floor_lift_mm=0), dict(floor_lift_mm=5)):
        with pytest.raises(ValueError):
            ReliefParams(**bad).validate()


# ------------------------------------------------------------------- mesh --
@pytest.mark.parametrize("shape", [(2, 2), (2, 7), (7, 2), (5, 9), (31, 17)])
def test_mesh_is_closed_and_volume_exact(shape):
    ny, nx = shape
    z = np.random.default_rng(0).uniform(3, 6, shape).astype(np.float32)
    m = build_solid_mesh(z, 40.0, 25.0)
    assert_closed_oriented_manifold(m.faces, m.n_vertices)
    expect = volume_under_surface(z.astype(np.float64), 40.0 / (nx - 1), 25.0 / (ny - 1))
    assert signed_volume(m) == pytest.approx(expect, rel=1e-5)
    assert m.n_faces == 2 * (nx - 1) * (ny - 1) + 2 * (2 * nx + 2 * ny - 4) + (2 * nx + 2 * ny - 4)


def test_trimesh_independent_validation():
    trimesh = pytest.importorskip("trimesh")
    z = np.random.default_rng(1).uniform(3, 6, (40, 30)).astype(np.float32)
    m = build_solid_mesh(z, 60.0, 80.0)
    t = trimesh.Trimesh(m.vertices, m.faces, process=False)
    assert t.is_watertight and t.is_winding_consistent and t.is_volume
    assert t.volume == pytest.approx(signed_volume(m), rel=1e-4)
    assert np.allclose(t.bounds[0], [0, 0, 0]) and np.allclose(t.bounds[1], [60, 80, z.max()], atol=1e-4)


# -------------------------------------------------------------------- STL --
def test_stl_roundtrip_and_normals(tmp_path):
    z = np.random.default_rng(2).uniform(3, 6, (12, 10)).astype(np.float32)
    m = build_solid_mesh(z, 20.0, 30.0)
    out = tmp_path / "t.stl"
    size = write_binary_stl(out, m, chunk=50)               # tiny chunks exercise the loop
    assert size == out.stat().st_size == m.stl_size_bytes
    assert not out.read_bytes()[:5].lower() == b"solid"
    tri = read_binary_stl(out)
    assert np.array_equal(tri, m.vertices[m.faces])
    raw = np.frombuffer(out.read_bytes()[84:], dtype=np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")]))
    assert np.allclose(np.linalg.norm(raw["n"], axis=1), 1.0, atol=1e-4)
    # top surface faces must point up, the bottom fan must point down
    n_top = 2 * 11 * 9
    assert (raw["n"][:n_top, 2] > 0).all()
    assert (raw["n"][-(2 * 10 + 2 * 12 - 4):, 2] < 0).all()
    assert not list(tmp_path.glob("*.tmp"))


# ---------------------------------------------------------------- pipeline --
def test_grid_matches_levels():
    for aspect in (0.5, 0.875, 1.0, 1.6):
        for level, target in MESH_LEVELS.items():
            nx, ny = compute_grid(int(3000 * aspect), 3000, level)
            faces = 2 * (nx - 1) * (ny - 1)
            assert abs(faces - target) / target < 0.03, (aspect, level, faces)
    assert compute_grid(300, 400, 1) == (300, 400)           # never upsamples beyond source


def test_end_to_end_dimensions_and_bounds(tmp_path):
    img = emblem(600, 800)
    p = ReliefParams(width_mm=100, relief_height_mm=3, base_mm=3, mesh_level=3)
    r = generate_relief(img, p)
    sx, sy, sz = r.stats.size_mm
    assert (sx, sy) == (100.0, pytest.approx(133.333, abs=0.01))
    assert sz == pytest.approx(3 + 3, abs=1e-4)             # base + relief
    assert r.z_mm.min() >= 3 + 0.1 - 1e-5                   # floor lift
    assert r.mask is not None and r.mask.mean() < 0.6       # background found
    assert r.depth[0, 0] == 0 and r.depth[-1, -1] == 0      # background forced to zero height
    assert_closed_oriented_manifold(r.mesh.faces, r.mesh.n_vertices)
    out = tmp_path / "relief.stl"
    write_binary_stl(out, r.mesh)
    assert out.stat().st_size == r.stats.stl_bytes


def test_negative_mode_inverts():
    img = emblem(300, 400)
    a = generate_relief(img, ReliefParams(mesh_level=5)).depth
    b = generate_relief(img, ReliefParams(mesh_level=5, negative=True)).depth
    assert np.allclose(a + b, 1.0, atol=1e-5)


def test_levels_and_invert():
    gray = np.tile(np.linspace(0, 1, 256, dtype=np.float32), (64, 1))
    base = dict(mode=ProcessingMode.DIRECT, use_mask=False, bg_trim=0, mesh_level=5)
    r = generate_relief(gray, ReliefParams(**base)).depth
    assert r[0, 0] == pytest.approx(0, abs=1e-4) and r[0, -1] == pytest.approx(1, abs=1e-4)
    inv = generate_relief(gray, ReliefParams(**base, invert_depth=True)).depth
    assert np.allclose(r + inv, 1.0, atol=1e-4)
    lv = generate_relief(gray, ReliefParams(**base, black_point=64, white_point=192)).depth
    assert lv[0, 50] == 0 and lv[0, -50] == 1               # clipped outside the level range
    g = generate_relief(gray, ReliefParams(**base, gamma=2.0)).depth
    assert (g[0, 128] > r[0, 128] + 0.1)                     # gamma > 1 lifts mid-tones


def test_high_pass_adds_detail():
    img = emblem(400, 400)
    direct = generate_relief(img, ReliefParams(mode=ProcessingMode.DIRECT, mesh_level=4)).depth
    hp = generate_relief(img, ReliefParams(mode=ProcessingMode.HIGH_PASS, detail_strength=0.5, mesh_level=4)).depth
    assert np.abs(hp - direct).max() > 0.1 and np.abs(hp - direct).mean() > 0.005
    det = generate_relief(img, ReliefParams(detail_only=True, use_mask=False, mesh_level=4)).depth
    assert 0.35 < det.mean() < 0.65                          # detail layer is centred around 0.5


# ----------------------------------------------------------------- masking --
def test_mask_color_key_and_alpha():
    img = emblem(300, 300)
    m = auto_foreground_mask(img, None, 30)
    assert m is not None and m[0, 0] == 0 and m[150, 150] == 1
    flat = np.full((50, 50, 3), 0.5, np.float32)
    assert auto_foreground_mask(flat, None, 30) is None      # nothing but background
    noisy = np.random.default_rng(0).uniform(0, 1, (50, 50, 3)).astype(np.float32)
    assert auto_foreground_mask(noisy, None, 30) is None     # border not uniform
    rgba = np.dstack([img, np.where(np.hypot(*np.mgrid[-150:150, -150:150]) < 100, 1.0, 0.0)]).astype(np.float32)
    li = from_array(rgba)
    ma = auto_foreground_mask(li.rgb, li.alpha)
    assert ma[150, 150] == 1 and ma[0, 0] == 0


def test_no_mask_note_when_background_unclear():
    noisy = np.random.default_rng(0).uniform(0, 1, (100, 100, 3)).astype(np.float32)
    r = generate_relief(noisy, ReliefParams(mesh_level=5))
    assert r.mask is None and r.notes


# ---------------------------------------------------------------------- IO --
def test_unicode_paths_and_16bit(tmp_path):
    folder = tmp_path / "শিমুল ছবি"
    folder.mkdir()
    g16 = (np.tile(np.linspace(0, 65535, 200), (100, 1))).astype(np.uint16)
    from PIL import Image
    path = folder / "গভীরতা.png"
    Image.fromarray(g16).save(path)
    li = load_image(path)
    assert li.rgb.shape == (100, 200, 3) and li.rgb.max() == pytest.approx(1.0, abs=1e-4)
    r = generate_relief(path, ReliefParams(mesh_level=5, use_mask=False))
    out = folder / "রিলিফ.stl"
    write_binary_stl(out, r.mesh)
    assert out.exists()
    save_png(folder / "d.png", r.depth)


def test_big_image_is_downscaled_on_load():
    big = np.zeros((4000, 3000), np.uint8)
    li = from_array(big)
    assert max(li.width, li.height) == 3072


def test_performance_level1_budget():
    img = np.random.default_rng(3).uniform(0, 1, (2048, 1536, 3)).astype(np.float32)
    t = time.perf_counter()
    r = generate_relief(img, ReliefParams(mesh_level=1, use_mask=False))
    dt = time.perf_counter() - t
    print(f"\nlevel 1: {r.stats.faces:,} faces in {dt:.2f}s")
    assert r.stats.faces > 1_900_000 and dt < 20
