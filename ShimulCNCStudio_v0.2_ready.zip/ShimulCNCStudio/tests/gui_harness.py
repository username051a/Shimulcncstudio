"""Helpers to drive the real window under Xvfb."""
import time
from PySide6.QtWidgets import QApplication, QMessageBox


def pump(app, seconds=0.05):
    end = time.time() + seconds
    while time.time() < end:
        app.processEvents()
        time.sleep(0.005)


def wait_until(app, cond, timeout=60.0, what="condition"):
    end = time.time() + timeout
    while time.time() < end:
        app.processEvents()
        if cond():
            return
        time.sleep(0.01)
    raise TimeoutError(f"timed out waiting for {what}")


def silence_dialogs():
    calls = []
    QMessageBox.warning = staticmethod(lambda *a, **k: calls.append(("warning", a[1:])) or QMessageBox.Ok)
    QMessageBox.information = staticmethod(lambda *a, **k: calls.append(("info", a[1:])) or QMessageBox.Ok)
    QMessageBox.question = staticmethod(lambda *a, **k: calls.append(("question", a[1:])) or QMessageBox.No)
    QMessageBox.exec = lambda self: calls.append(("exec", self.text())) or 0
    QMessageBox.clickedButton = lambda self: None
    return calls
