# Shimul CNC Studio

Windows program that turns an image into a depth map and a 2.5D relief, and exports a
watertight binary **STL** for CNC. Free and offline: no paid tools, no paid APIs.

* **Depth source:** AI (Depth Anything V2 Small, Apache-2.0, runs on your PC) or manual grayscale.
* **Workflow:** Design (image + depth source) -> Crop (crop, rotate, flip) -> Mesh (filters, 3D view, export).
* **Filters:** High-Pass detail, base smooth, groove deepen, levels (black / gamma / white), background mask and trim, negative (mould) mode.
* **3D view:** orbit, pan, zoom, shaded / normal map / texture / wireframe.
* **Mesh levels:** 1 (2M triangles) to 5 (100k). The export is always exactly the level you chose.

## Three ways to get it running (Windows)

### A. Try it now: double-click `run_app.bat`
Needs Python 3.12 (64-bit) from python.org. The first start installs the libraries (internet needed once).
Python 3.15 may not have ready-made packages for every library yet, so 3.12 is the safe choice.

### B. Build the .exe and installer yourself: double-click `build_windows.bat`
Creates `dist\ShimulCNCStudio\ShimulCNCStudio.exe` and, if the free
[Inno Setup 6](https://jrsoftware.org/isinfo.php) is installed, `dist\ShimulCNCStudio_Setup_<version>.exe`.
The AI model (about 99 MB) is downloaded during the build and packed into the installer, so the finished
program works offline from the first start.

### C. Let GitHub build it for you (nothing to install)
1. Create a free GitHub account and a new repository, then upload the contents of this folder.
2. Open the **Actions** tab, choose **Build Windows installer**, press **Run workflow**.
3. After a few minutes download the artifact `ShimulCNCStudio-Windows` (setup .exe, portable .zip and `selftest.txt`).

## If something does not work
* Logs: `%LOCALAPPDATA%\ShimulCNCStudio\app.log`
* 3D view is black or missing: start with `run_app.bat --software-viewport` (shaded 2D preview). The program also switches by itself if OpenGL cannot start.
* AI depth: the model is looked up in `models\`, then `%LOCALAPPDATA%\ShimulCNCStudio\models\`. You can download or import it on the **Design** page.
* Built-in check of a finished build: `ShimulCNCStudio.exe --selftest report.txt`.

## Command line (no window)
```
python -m shimul_cnc input.png output.stl --width 100 --relief 3 --base 3 --level 3
```

## For developers
```
pip install -r requirements-dev.txt
python -m pytest tests        # engine, AI plumbing, full GUI flow
```
* `shimul_cnc/core`   engine: depth, filters, mesh, STL (no GUI dependency)
* `shimul_cnc/ai`     model manager and ONNX depth estimator
* `shimul_cnc/ui`     PySide6 interface and OpenGL viewport
* `shimul_cnc/licensing.py`  hook for a future licence / login check (free edition today)

Notes: coordinates are X right, Y up, Z up; the solid sits on Z = 0 and its top is base + relief.
Pixel-based settings are defined at a 1024-px reference size, so results look the same at every mesh level.
