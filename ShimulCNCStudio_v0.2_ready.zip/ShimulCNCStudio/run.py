import sys

from shimul_cnc.app import main

if __name__ == "__main__":
    sys.exit(main())
